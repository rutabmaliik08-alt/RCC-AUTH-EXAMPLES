#pragma once

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <wininet.h>
#include <wincrypt.h>
#include <iostream>
#include <string>
#include <vector>
#include <sstream>
// Embedded skCrypt compile-time string encryption
#ifndef SKCRYPT_HPP
#define SKCRYPT_HPP
namespace skc {
    template <int N>
    struct CompileTimeRandom {
        static constexpr unsigned int value = 0x5A1F7B9C ^ (N * 0x45D9F3B);
    };

    template <size_t N, unsigned int Key>
    class EncryptedString {
    private:
        char m_data[N];
    public:
        constexpr EncryptedString(const char* str) : m_data{} {
            for (size_t i = 0; i < N; ++i) {
                m_data[i] = str[i] ^ (char)((Key + i) & 0xFF);
            }
        }

        std::string decrypt() const {
            std::string decrypted;
            decrypted.resize(N - 1);
            for (size_t i = 0; i < N - 1; ++i) {
                decrypted[i] = m_data[i] ^ (char)((Key + i) & 0xFF);
            }
            return decrypted;
        }
    };
}

#define skCrypt(str) []() -> std::string { \
    constexpr size_t len = sizeof(str); \
    constexpr unsigned int key = skc::CompileTimeRandom<__LINE__>::value; \
    static const skc::EncryptedString<len, key> enc(str); \
    return enc.decrypt(); \
}()
#endif

#pragma comment(lib, "wininet.lib")
#pragma comment(lib, "crypt32.lib")
#pragma comment(lib, "advapi32.lib")

namespace RCCAuthSDK {

    struct ResponseData {
        bool success = false;
        std::string message;
    };

    struct UserData {
        std::string username;
        std::string ip;
        std::string hwid;
        std::string createdate;
        std::string lastlogin;
        std::string subscription = "Default";
        std::string expiry;
        int rank = 1;
        long long remainingSeconds = -1;
    };

    class api {
    private:
        std::string m_name;
        std::string m_ownerid;
        std::string m_secret;
        std::string m_version;
        std::string m_url;
        std::string m_path;
        std::string m_sessionId;
        bool m_initialized = false;

    public:
        ResponseData response;
        UserData data;

        api(const std::string& name, const std::string& ownerid, const std::string& secret, const std::string& version, const std::string& url = "http://127.0.0.1:3000/api/v1/", const std::string& path = "")
            : m_name(name), m_ownerid(ownerid), m_secret(secret), m_version(version), m_url(url), m_path(path) {
            // Trim trailing slash from url if needed
            if (!m_url.empty() && m_url.back() == '/') {
                // Keep clean base url
            }
        }

        // HWID Generator
        static std::string get_hwid() {
            char computerName[MAX_COMPUTERNAME_LENGTH + 1];
            DWORD size = sizeof(computerName);
            GetComputerNameA(computerName, &size);

            DWORD volumeSerial = 0;
            GetVolumeInformationA("C:\\", NULL, 0, &volumeSerial, NULL, NULL, NULL, 0);

            std::stringstream ss;
            ss << computerName << "-" << volumeSerial;
            return sha256(ss.str());
        }

        static std::string sha256(const std::string& input) {
            HCRYPTPROV hProv = 0;
            HCRYPTHASH hHash = 0;
            BYTE hash[32];
            DWORD cbHash = 32;
            std::stringstream ss;

            if (CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_AES, CRYPT_VERIFYCONTEXT)) {
                if (CryptCreateHash(hProv, CALG_SHA_256, 0, 0, &hHash)) {
                    if (CryptHashData(hHash, (BYTE*)input.c_str(), (DWORD)input.length(), 0)) {
                        if (CryptGetHashParam(hHash, HP_HASHVAL, hash, &cbHash, 0)) {
                            for (DWORD i = 0; i < cbHash; i++) {
                                ss << std::hex << std::setw(2) << std::setfill('0') << (int)hash[i];
                            }
                        }
                    }
                    CryptDestroyHash(hHash);
                }
                CryptReleaseContext(hProv, 0);
            }
            return ss.str();
        }

        // Initialize Application
        void init() {
            std::string payload = "{\"name\":\"" + escape_json(m_name) + "\",\"ownerid\":\"" + escape_json(m_ownerid) + "\",\"secret\":\"" + escape_json(m_secret) + "\",\"version\":\"" + escape_json(m_version) + "\"}";
            std::string res;
            if (http_post("init", payload, res)) {
                std::string successVal = extract_json_bool(res, "success");
                response.success = (successVal == "true");
                response.message = extract_json_string(res, "message");
                if (response.success) {
                    m_sessionId = extract_json_string(res, "session_id");
                    m_initialized = true;
                }
            } else {
                response.success = false;
                response.message = "Failed to connect to authentication server.";
            }
        }

        // User Login
        void login(const std::string& username, const std::string& password) {
            if (!m_initialized) { init(); if (!response.success) return; }
            std::string hwid = get_hwid();
            std::string payload = "{\"secret\":\"" + escape_json(m_secret) + "\",\"ownerid\":\"" + escape_json(m_ownerid) + "\",\"username\":\"" + escape_json(username) + "\",\"password\":\"" + escape_json(password) + "\",\"hwid\":\"" + hwid + "\"}";
            std::string res;
            if (http_post("login", payload, res)) {
                response.success = (extract_json_bool(res, "success") == "true");
                response.message = extract_json_string(res, "message");
                if (response.success) {
                    parse_user(res);
                }
            } else {
                response.success = false;
                response.message = "Network error during login.";
            }
        }

        // User Registration
        void regstr(const std::string& username, const std::string& password, const std::string& key) {
            if (!m_initialized) { init(); if (!response.success) return; }
            std::string hwid = get_hwid();
            std::string payload = "{\"secret\":\"" + escape_json(m_secret) + "\",\"ownerid\":\"" + escape_json(m_ownerid) + "\",\"username\":\"" + escape_json(username) + "\",\"password\":\"" + escape_json(password) + "\",\"license_key\":\"" + escape_json(key) + "\",\"hwid\":\"" + hwid + "\"}";
            std::string res;
            if (http_post("register", payload, res)) {
                response.success = (extract_json_bool(res, "success") == "true");
                response.message = extract_json_string(res, "message");
                if (response.success) {
                    parse_user(res);
                }
            } else {
                response.success = false;
                response.message = "Network error during registration.";
            }
        }

        // License Only Auth
        void license(const std::string& key) {
            if (!m_initialized) { init(); if (!response.success) return; }
            std::string hwid = get_hwid();
            std::string payload = "{\"secret\":\"" + escape_json(m_secret) + "\",\"ownerid\":\"" + escape_json(m_ownerid) + "\",\"license_key\":\"" + escape_json(key) + "\",\"hwid\":\"" + hwid + "\"}";
            std::string res;
            if (http_post("license", payload, res)) {
                response.success = (extract_json_bool(res, "success") == "true");
                response.message = extract_json_string(res, "message");
                if (response.success) {
                    parse_user(res);
                }
            } else {
                response.success = false;
                response.message = "Network error during license authentication.";
            }
        }

        // Cloud Variable Fetch
        std::string var(const std::string& var_name) {
            if (!m_initialized) { init(); if (!response.success) return ""; }
            std::string payload = "{\"secret\":\"" + escape_json(m_secret) + "\",\"var_name\":\"" + escape_json(var_name) + "\"}";
            std::string res;
            if (http_post("var", payload, res)) {
                return extract_json_string(res, "var_value");
            }
            return "";
        }

        // Send Audit Log
        void log(const std::string& message) {
            std::string payload = "{\"secret\":\"" + escape_json(m_secret) + "\",\"message\":\"" + escape_json(message) + "\"}";
            std::string res;
            http_post("log", payload, res);
        }

    private:
        bool http_post(const std::string& endpoint, const std::string& jsonPayload, std::string& responseOut) {
            HINTERNET hInternet = InternetOpenA("RCCAuth-Client/2.0", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
            if (!hInternet) return false;

            std::string host = "127.0.0.1";
            INTERNET_PORT port = 3000;
            DWORD flags = INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE;

            std::string cleanUrl = m_url;
            bool isHttps = false;
            if (cleanUrl.rfind("https://", 0) == 0) {
                cleanUrl = cleanUrl.substr(8);
                port = INTERNET_DEFAULT_HTTPS_PORT;
                flags |= INTERNET_FLAG_SECURE;
                isHttps = true;
            } else if (cleanUrl.rfind("http://", 0) == 0) {
                cleanUrl = cleanUrl.substr(7);
                port = INTERNET_DEFAULT_HTTP_PORT;
            }

            size_t slashPos = cleanUrl.find('/');
            std::string basePath = "/api/v1/";
            if (slashPos != std::string::npos) {
                host = cleanUrl.substr(0, slashPos);
                basePath = cleanUrl.substr(slashPos);
            } else {
                host = cleanUrl;
            }

            size_t colonPos = host.find(':');
            if (colonPos != std::string::npos) {
                port = (INTERNET_PORT)std::stoi(host.substr(colonPos + 1));
                host = host.substr(0, colonPos);
            }

            if (basePath.empty() || basePath.back() != '/') {
                basePath += "/";
            }
            std::string fullPath = basePath + endpoint;

            HINTERNET hConnect = InternetConnectA(hInternet, host.c_str(), port, NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
            if (!hConnect) { InternetCloseHandle(hInternet); return false; }

            HINTERNET hRequest = HttpOpenRequestA(hConnect, "POST", fullPath.c_str(), NULL, NULL, NULL, flags, 0);
            if (!hRequest) { InternetCloseHandle(hConnect); InternetCloseHandle(hInternet); return false; }

            std::string headers = "Content-Type: application/json\r\nAccept: application/json\r\n";
            BOOL sendOk = HttpSendRequestA(hRequest, headers.c_str(), (DWORD)headers.length(), (LPVOID)jsonPayload.c_str(), (DWORD)jsonPayload.length());

            if (sendOk) {
                char buffer[4096];
                DWORD bytesRead = 0;
                std::stringstream responseStream;
                while (InternetReadFile(hRequest, buffer, sizeof(buffer) - 1, &bytesRead) && bytesRead > 0) {
                    buffer[bytesRead] = '\0';
                    responseStream << buffer;
                }
                responseOut = responseStream.str();
            }

            InternetCloseHandle(hRequest);
            InternetCloseHandle(hConnect);
            InternetCloseHandle(hInternet);
            return sendOk == TRUE;
        }

        void parse_user(const std::string& res) {
            data.username = extract_json_string(res, "username");
            data.ip = extract_json_string(res, "ip");
            data.hwid = extract_json_string(res, "hwid");
            data.expiry = extract_json_string(res, "expires_at");
            data.createdate = extract_json_string(res, "created_at");
            data.lastlogin = extract_json_string(res, "last_login");
            data.subscription = data.expiry.empty() || data.expiry == "Lifetime" ? "Lifetime Active" : "Active (" + data.expiry + ")";
        }

        std::string escape_json(const std::string& str) {
            std::string res;
            for (char c : str) {
                if (c == '"') res += "\\\"";
                else if (c == '\\') res += "\\\\";
                else res += c;
            }
            return res;
        }

        std::string extract_json_string(const std::string& json, const std::string& key) {
            std::string pattern = "\"" + key + "\":\"";
            size_t start = json.find(pattern);
            if (start != std::string::npos) {
                start += pattern.length();
                size_t end = json.find("\"", start);
                if (end != std::string::npos) {
                    return json.substr(start, end - start);
                }
            }
            return "";
        }

        std::string extract_json_bool(const std::string& json, const std::string& key) {
            std::string pattern = "\"" + key + "\":";
            size_t start = json.find(pattern);
            if (start != std::string::npos) {
                start += pattern.length();
                if (json.substr(start, 4) == "true") return "true";
                if (json.substr(start, 5) == "false") return "false";
            }
            return "";
        }
    };

    // Typedef alias for backward compatibility
    using RCCAuth = api;
}

namespace RCCAuth = RCCAuthSDK;

