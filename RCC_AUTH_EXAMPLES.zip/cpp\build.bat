@echo off
echo ===================================================
echo Compiling RCC AUTH C++ Client with MSVC...
echo ===================================================

where cl.exe >nul 2>nul
if %errorlevel% neq 0 (
    echo [*] Setting up Visual Studio 2022 Developer Environment...
    call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"
)

cl.exe /EHsc /std:c++20 /D_CRT_SECURE_NO_WARNINGS main.cpp /Fe:RCCAuthClient.exe

if %errorlevel% equ 0 (
    echo.
    echo [+] Compilation Successful! Generated: RCCAuthClient.exe
) else (
    echo.
    echo [!] Compilation Failed.
)
