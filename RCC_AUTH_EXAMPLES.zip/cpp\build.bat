@echo off
title Building RCC Auth C++ Client
echo ========================================================
echo Building RCC AUTH C++ Client Demonstration
echo ========================================================

where cl >nul 2>nul
if %errorlevel% neq 0 (
    echo [!] Microsoft Visual C++ Compiler (cl.exe) not found in PATH.
    echo [!] Please run this from 'x64 Native Tools Command Prompt for VS'.
    pause
    exit /b 1
)

echo [*] Compiling main.cpp...
cl.exe /EHsc /std:c++17 /O2 main.cpp /link wininet.lib crypt32.lib advapi32.lib /out:RCCAuthDemo.exe

if %errorlevel% equ 0 (
    echo [✓] Build Succeeded! Generated RCCAuthDemo.exe
    del *.obj 2>nul
) else (
    echo [X] Build Failed!
)

pause
