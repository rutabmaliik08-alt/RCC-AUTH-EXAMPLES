import requests
import hashlib
import platform
import subprocess
import json
import os
import sys
import urllib3

# Suppress insecure HTTPS warnings if connecting with custom/self-signed certs
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class ResponseData:
    def __init__(self):
        self.success = False
        self.message = ""

class UserData:
    def __init__(self):
        self.username = ""
        self.ip = ""
        self.hwid = ""
        self.createdate = ""
        self.lastlogin = ""
        self.subscription = "Default"
        self.expiry = "Lifetime"
        self.rank = 1
        self.remaining_seconds = -1

class api:
    """
    RCC AUTH Python Client SDK (v2.0)
    Supports cloud authentication, license verification, HWID locking, and cloud variables.
    """
    def __init__(self, name: str, ownerid: str, secret: str, version: str, url: str = "http://127.0.0.1:3000/api/v1/", path: str = ""):
        self.name = name
        self.ownerid = ownerid
        self.secret = secret
        self.version = version
        self.url = url.rstrip('/') + '/'
        self.path = path
        self.session_id = None
        self.response = ResponseData()
        self.data = UserData()
        self._initialized = False

    @staticmethod
    def get_hwid() -> str:
        """Generates a stable hardware ID for Windows machine"""
        try:
            cmd = 'wmic csproduct get uuid'
            output = subprocess.check_output(cmd, shell=True, stderr=subprocess.DEVNULL).decode().split('\n')
            uuid = output[1].strip() if len(output) > 1 else ""
            if not uuid:
                uuid = platform.node() + "-" + platform.machine()
            return hashlib.sha256(uuid.encode()).hexdigest()
        except:
            fallback = platform.node() + "-" + platform.processor()
            return hashlib.sha256(fallback.encode()).hexdigest()

    def checkblack(self) -> bool:
        return False

    def _post(self, endpoint: str, data: dict) -> dict:
        full_url = f"{self.url}{endpoint}"
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "x-app-secret": self.secret
        }
        try:
            res = requests.post(full_url, json=data, headers=headers, timeout=15, verify=False)
            return res.json()
        except Exception as e:
            return {"success": False, "message": f"Network error: {str(e)}"}

    def init(self):
        """Initializes handshake with the authentication server"""
        payload = {
            "name": self.name,
            "ownerid": self.ownerid,
            "secret": self.secret,
            "version": self.version
        }
        res = self._post("init", payload)
        self.response.success = res.get("success", False)
        self.response.message = res.get("message", "Unknown server response")
        if self.response.success:
            self.session_id = res.get("session_id")
            self._initialized = True

    def login(self, username: str, password: str):
        """Authenticates user account with HWID lock"""
        if not self._initialized:
            self.init()
            if not self.response.success: return
            
        payload = {
            "secret": self.secret,
            "ownerid": self.ownerid,
            "username": username,
            "password": password,
            "hwid": self.get_hwid()
        }
        res = self._post("login", payload)
        self._handle_auth_response(res)

    def regstr(self, username: str, password: str, license_key: str):
        """Registers new user with a valid license key"""
        if not self._initialized:
            self.init()
            if not self.response.success: return

        payload = {
            "secret": self.secret,
            "ownerid": self.ownerid,
            "username": username,
            "password": password,
            "license_key": license_key,
            "hwid": self.get_hwid()
        }
        res = self._post("register", payload)
        self._handle_auth_response(res)

    def license(self, license_key: str):
        """Authenticates a license key directly without username/password"""
        if not self._initialized:
            self.init()
            if not self.response.success: return

        payload = {
            "secret": self.secret,
            "ownerid": self.ownerid,
            "license_key": license_key,
            "hwid": self.get_hwid()
        }
        res = self._post("license", payload)
        self._handle_auth_response(res)

    def upgrade(self, username: str, license_key: str):
        """Extends an existing user account subscription using a license key"""
        if not self._initialized:
            self.init()
            if not self.response.success: return

        payload = {
            "secret": self.secret,
            "username": username,
            "license_key": license_key
        }
        res = self._post("upgrade", payload)
        self.response.success = res.get("success", False)
        self.response.message = res.get("message", "Upgrade completed")

    def var(self, var_name: str) -> str:
        """Fetches an encrypted cloud variable set in RCC Auth dashboard"""
        if not self._initialized:
            self.init()
            if not self.response.success: return ""

        payload = {
            "secret": self.secret,
            "var_name": var_name
        }
        res = self._post("var", payload)
        if res.get("success"):
            return res.get("var_value", "")
        return ""

    def log(self, message: str):
        """Dispatches an audit log event to the RCC Auth dashboard"""
        payload = {
            "secret": self.secret,
            "message": message,
            "hwid": self.get_hwid()
        }
        self._post("log", payload)

    def _handle_auth_response(self, res: dict):
        self.response.success = res.get("success", False)
        self.response.message = res.get("message", "")

        if self.response.success:
            user = res.get("user", {})
            if isinstance(user, dict) and user:
                self.data.username = user.get("username", "")
                self.data.hwid = user.get("hwid", "")
                self.data.ip = user.get("ip", "")
                self.data.rank = user.get("rank", 1)
                self.data.expiry = user.get("expires_at") or "Lifetime"
                self.data.createdate = user.get("created_at", "")
                self.data.lastlogin = user.get("last_login", "")
                self.data.remaining_seconds = user.get("remaining_seconds", -1)
                self.data.subscription = "Lifetime Active" if (not user.get("expires_at") or user.get("expires_at") == "Lifetime") else f"Active ({self.data.expiry})"
            else:
                self.data.username = res.get("username", "")
                self.data.hwid = res.get("hwid", "")
                self.data.expiry = res.get("expires_at") or "Lifetime"
                self.data.subscription = "Lifetime Active" if (not res.get("expires_at") or res.get("expires_at") == "Lifetime") else f"Active ({self.data.expiry})"
