import requests
import hashlib
import platform
import subprocess
import json
import os
import sys

class ResponseData:
    def __init__(self):
        self.success = False
        self.message = ""

class UserData:
    def __init__(self):
        self.username = ""
        self.ip = ""
        self.hwid = ""
        self.createdate = ""
        self.lastlogin = ""
        self.subscription = "Default"
        self.expiry = ""
        self.rank = 1

class api:
    """
    RCC AUTH Python Client SDK (RCC AUTH Architecture)
    Supports full cloud authentication, license verification, HWID locking, and cloud variables.
    """
    def __init__(self, name: str, ownerid: str, secret: str, version: str, url: str = "http://127.0.0.1:3000/api/v1/", path: str = ""):
        self.name = name
        self.ownerid = ownerid
        self.secret = secret
        self.version = version
        self.url = url.rstrip('/') + '/'
        self.path = path
        self.session_id = None
        self.response = ResponseData()
        self.data = UserData()
        self._initialized = False

    @staticmethod
    def get_hwid() -> str:
        """Generates a hardware ID for Windows machine"""
        try:
            cmd = 'wmic csproduct get uuid'
            uuid = subprocess.check_output(cmd, shell=True).decode().split('\n')[1].strip()
            if not uuid:
                uuid = platform.node() + "-" + platform.machine()
            return hashlib.sha256(uuid.encode()).hexdigest()
        except:
            return hashlib.sha256((platform.node() + platform.processor()).encode()).hexdigest()

    def _post(self, endpoint: str, data: dict) -> dict:
        full_url = f"{self.url}{endpoint}"
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "x-app-secret": self.secret
        }
        try:
            res = requests.post(full_url, json=data, headers=headers, timeout=12)
            return res.json()
        except Exception as e:
            return {"success": False, "message": f"Network error: {str(e)}"}

    def init(self):
        """Initializes handshake with the authentication server"""
        payload = {
            "name": self.name,
            "ownerid": self.ownerid,
            "secret": self.secret,
            "version": self.version
        }
        res = self._post("init", payload)
        self.response.success = res.get("success", False)
        self.response.message = res.get("message", "Unknown response")
        if self.response.success:
            self.session_id = res.get("session_id")
            self._initialized = True

    def login(self, username: str, password: str):
        """Authenticates user account with HWID lock"""
        if not self._initialized:
            self.init()
            if not self.response.success: return
            
        payload = {
            "secret": self.secret,
            "ownerid": self.ownerid,
            "username": username,
            "password": password,
            "hwid": self.get_hwid()
        }
        res = self._post("login", payload)
        self._handle_auth_response(res)

    def regstr(self, username: str, password: str, license_key: str):
        """Registers new user with a valid license key"""
        if not self._initialized:
            self.init()
            if not self.response.success: return

        payload = {
            "secret": self.secret,
            "ownerid": self.ownerid,
            "username": username,
            "password": password,
            "license_key": license_key,
            "hwid": self.get_hwid()
        }
        res = self._post("register", payload)
        self._handle_auth_response(res)

    def register(self, username: str, password: str, license_key: str):
        self.regstr(username, password, license_key)

    def license(self, license_key: str):
        """Direct 1-Click License authentication"""
        if not self._initialized:
            self.init()
            if not self.response.success: return

        payload = {
            "secret": self.secret,
            "ownerid": self.ownerid,
            "license_key": license_key,
            "hwid": self.get_hwid()
        }
        res = self._post("license", payload)
        self._handle_auth_response(res)

    def var(self, var_name: str) -> str:
        """Fetches remote cloud variable"""
        if not self._initialized:
            self.init()
            if not self.response.success: return ""

        payload = {
            "secret": self.secret,
            "var_name": var_name
        }
        res = self._post("var", payload)
        if res.get("success"):
            return res.get("var_value", "")
        return ""

    def download(self, file_id: str) -> bytes:
        """Downloads encrypted binary file directly to memory buffer"""
        if not self._initialized:
            self.init()
            if not self.response.success: return b""

        payload = {
            "secret": self.secret,
            "file_id": file_id
        }
        res = self._post("download", payload)
        if res.get("success") and "file_data" in res:
            import base64
            return base64.b64decode(res["file_data"])
        return b""

    def log(self, message: str):
        """Sends security audit log to server"""
        payload = {
            "secret": self.secret,
            "message": message
        }
        self._post("log", payload)

    def _handle_auth_response(self, res: dict):
        self.response.success = res.get("success", False)
        self.response.message = res.get("message", "")
        if self.response.success:
            user = res.get("user", {})
            self.data.username = user.get("username", "")
            self.data.hwid = user.get("hwid", "")
            self.data.rank = user.get("rank", 1)
            self.data.expiry = user.get("expires_at", "Lifetime")
            self.data.createdate = user.get("created_at", "")
            self.data.lastlogin = user.get("last_login", "")
            self.data.subscription = "Lifetime Active" if not self.data.expiry or self.data.expiry == "Lifetime" else f"Active ({self.data.expiry})"

# Alias for backwards compatibility
RCCAuth = api
