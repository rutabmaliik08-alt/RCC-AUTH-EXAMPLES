#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commctrl.h>
#include <thread>
#include <string>
#include "RCCAuth.hpp"

#pragma comment(linker, "\"/manifestdependency:type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")

using namespace RCCAuthSDK;

// Server Configuration
const std::string SERVER_URL = "http://127.0.0.1:3000";
const std::string APP_NAME = "RCCLoader";
const std::string APP_SECRET = "RCCSec_9f83a12b4e76c5d9";
const std::string VERSION = "1.0.0";

RCCAuth g_Auth(SERVER_URL, APP_NAME, APP_SECRET, VERSION);

// UI States
enum AppState {
    STATE_LOGIN = 0,
    STATE_MAIN_DASHBOARD = 1
};

AppState g_CurrentState = STATE_LOGIN;
int g_LoginTab = 0; // 0: Login, 1: Register, 2: Key Only

// Colors
const COLORREF COLOR_BG = RGB(11, 15, 25);         // #0B0F19 Dark Navy
const COLORREF COLOR_CARD = RGB(17, 24, 39);       // #111827
const COLORREF COLOR_TEXT = RGB(243, 244, 246);    // Slate 100
const COLORREF COLOR_MUTED = RGB(148, 163, 184);   // Slate 400
const COLORREF COLOR_CYAN = RGB(6, 182, 212);      // Cyan 500
const COLORREF COLOR_GREEN = RGB(16, 185, 129);    // Emerald 500
const COLORREF COLOR_RED = RGB(244, 63, 94);       // Rose 500

HBRUSH g_hBrushBg = NULL;
HBRUSH g_hBrushCard = NULL;
HFONT g_hFontTitle = NULL;
HFONT g_hFontBody = NULL;
HFONT g_hFontSmall = NULL;

// Control IDs
#define IDC_TAB_LOGIN     101
#define IDC_TAB_REGISTER  102
#define IDC_TAB_KEYONLY   103
#define IDC_EDIT_USER     104
#define IDC_EDIT_PASS     105
#define IDC_EDIT_KEY      106
#define IDC_BTN_ACTION    107
#define IDC_LBL_STATUS    108
#define IDC_BTN_LOGOUT    109
#define IDC_BTN_INJECT    110
#define IDC_BTN_FETCH_VAR 111
#define IDC_CHK_AIMBOT    112
#define IDC_CHK_ESP       113
#define IDC_CHK_OBS       114

// Window Handles
HWND g_hWndMain = NULL;
HWND g_hEditUser = NULL;
HWND g_hEditPass = NULL;
HWND g_hEditKey = NULL;
HWND g_hBtnAction = NULL;
HWND g_hLblStatus = NULL;
HWND g_hBtnTab1 = NULL;
HWND g_hBtnTab2 = NULL;
HWND g_hBtnTab3 = NULL;

// Main Dashboard Controls
HWND g_hBtnLogout = NULL;
HWND g_hBtnInject = NULL;
HWND g_hBtnFetchVar = NULL;
HWND g_hChkAimbot = NULL;
HWND g_hChkEsp = NULL;
HWND g_hChkObs = NULL;

std::string g_StatusText = "Ready. Connected to RCC AUTH Sentinel.";
COLORREF g_StatusColor = COLOR_MUTED;
bool g_IsBusy = false;

void SetStatus(const std::string& text, COLORREF color = COLOR_MUTED) {
    g_StatusText = text;
    g_StatusColor = color;
    InvalidateRect(g_hWndMain, NULL, TRUE);
}

void UpdateControlVisibility() {
    bool isLoginScreen = (g_CurrentState == STATE_LOGIN);

    // Login Screen Controls
    ShowWindow(g_hBtnTab1, isLoginScreen ? SW_SHOW : SW_HIDE);
    ShowWindow(g_hBtnTab2, isLoginScreen ? SW_SHOW : SW_HIDE);
    ShowWindow(g_hBtnTab3, isLoginScreen ? SW_SHOW : SW_HIDE);
    ShowWindow(g_hBtnAction, isLoginScreen ? SW_SHOW : SW_HIDE);

    if (isLoginScreen) {
        if (g_LoginTab == 0) { // Login
            ShowWindow(g_hEditUser, SW_SHOW);
            ShowWindow(g_hEditPass, SW_SHOW);
            ShowWindow(g_hEditKey, SW_HIDE);
            SetWindowTextA(g_hBtnAction, "Sign In to RCC AUTH");
        } else if (g_LoginTab == 1) { // Register
            ShowWindow(g_hEditUser, SW_SHOW);
            ShowWindow(g_hEditPass, SW_SHOW);
            ShowWindow(g_hEditKey, SW_SHOW);
            SetWindowTextA(g_hBtnAction, "Register Account");
        } else { // Key Only
            ShowWindow(g_hEditUser, SW_HIDE);
            ShowWindow(g_hEditPass, SW_HIDE);
            ShowWindow(g_hEditKey, SW_SHOW);
            SetWindowTextA(g_hBtnAction, "Activate License Key");
        }
    } else {
        ShowWindow(g_hEditUser, SW_HIDE);
        ShowWindow(g_hEditPass, SW_HIDE);
        ShowWindow(g_hEditKey, SW_HIDE);
    }

    // Dashboard Controls
    ShowWindow(g_hBtnLogout, !isLoginScreen ? SW_SHOW : SW_HIDE);
    ShowWindow(g_hBtnInject, !isLoginScreen ? SW_SHOW : SW_HIDE);
    ShowWindow(g_hBtnFetchVar, !isLoginScreen ? SW_SHOW : SW_HIDE);
    ShowWindow(g_hChkAimbot, !isLoginScreen ? SW_SHOW : SW_HIDE);
    ShowWindow(g_hChkEsp, !isLoginScreen ? SW_SHOW : SW_HIDE);
    ShowWindow(g_hChkObs, !isLoginScreen ? SW_SHOW : SW_HIDE);

    InvalidateRect(g_hWndMain, NULL, TRUE);
}

void DoAuthAction() {
    if (g_IsBusy) return;
    g_IsBusy = true;

    char userBuf[128] = { 0 };
    char passBuf[128] = { 0 };
    char keyBuf[128] = { 0 };

    GetWindowTextA(g_hEditUser, userBuf, sizeof(userBuf));
    GetWindowTextA(g_hEditPass, passBuf, sizeof(passBuf));
    GetWindowTextA(g_hEditKey, keyBuf, sizeof(keyBuf));

    std::string user = userBuf;
    std::string pass = passBuf;
    std::string key = keyBuf;

    std::thread([=]() {
        SetStatus("Connecting to RCC AUTH Sentinel...", COLOR_CYAN);

        std::string msg;
        bool ok = false;

        if (g_LoginTab == 0) { // Login
            if (user.empty() || pass.empty()) {
                SetStatus("Error: Username and Password required.", COLOR_RED);
                g_IsBusy = false;
                return;
            }
            ok = g_Auth.Login(user, pass, msg);
        } else if (g_LoginTab == 1) { // Register
            if (user.empty() || pass.empty() || key.empty()) {
                SetStatus("Error: All fields are required for registration.", COLOR_RED);
                g_IsBusy = false;
                return;
            }
            ok = g_Auth.Register(user, pass, key, msg);
        } else { // Key Only
            if (key.empty()) {
                SetStatus("Error: Please enter a License Key.", COLOR_RED);
                g_IsBusy = false;
                return;
            }
            ok = g_Auth.LicenseAuth(key, msg);
        }

        if (ok) {
            SetStatus("Authentication Successful! Loading dashboard...", COLOR_GREEN);
            Sleep(800);
            g_CurrentState = STATE_MAIN_DASHBOARD;
            PostMessage(g_hWndMain, WM_USER + 1, 0, 0);
        } else {
            SetStatus("Failed: " + msg, COLOR_RED);
        }

        g_IsBusy = false;
    }).detach();
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_CREATE: {
        g_hBrushBg = CreateSolidBrush(COLOR_BG);
        g_hBrushCard = CreateSolidBrush(COLOR_CARD);

        g_hFontTitle = CreateFontA(22, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Segoe UI");
        g_hFontBody = CreateFontA(15, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Segoe UI");
        g_hFontSmall = CreateFontA(12, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Segoe UI");

        // Login Screen Tabs
        g_hBtnTab1 = CreateWindowA("BUTTON", "Login", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 40, 70, 130, 32, hWnd, (HMENU)IDC_TAB_LOGIN, NULL, NULL);
        g_hBtnTab2 = CreateWindowA("BUTTON", "Register", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 180, 70, 130, 32, hWnd, (HMENU)IDC_TAB_REGISTER, NULL, NULL);
        g_hBtnTab3 = CreateWindowA("BUTTON", "Key Only", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 320, 70, 130, 32, hWnd, (HMENU)IDC_TAB_KEYONLY, NULL, NULL);

        // Edit Inputs
        g_hEditUser = CreateWindowExA(WS_EX_CLIENTEDGE, "EDIT", "", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 40, 135, 410, 30, hWnd, (HMENU)IDC_EDIT_USER, NULL, NULL);
        g_hEditPass = CreateWindowExA(WS_EX_CLIENTEDGE, "EDIT", "", WS_CHILD | WS_VISIBLE | ES_PASSWORD | ES_AUTOHSCROLL, 40, 195, 410, 30, hWnd, (HMENU)IDC_EDIT_PASS, NULL, NULL);
        g_hEditKey = CreateWindowExA(WS_EX_CLIENTEDGE, "EDIT", "", WS_CHILD | ES_AUTOHSCROLL, 40, 255, 410, 30, hWnd, (HMENU)IDC_EDIT_KEY, NULL, NULL);

        // Action Button
        g_hBtnAction = CreateWindowA("BUTTON", "Sign In to RCC AUTH", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 40, 305, 410, 40, hWnd, (HMENU)IDC_BTN_ACTION, NULL, NULL);

        // Dashboard Screen Controls
        g_hChkAimbot = CreateWindowA("BUTTON", " Enable Aimbot (Smooth 1.5, FOV 90)", WS_CHILD | BS_AUTOCHECKBOX, 50, 160, 380, 24, hWnd, (HMENU)IDC_CHK_AIMBOT, NULL, NULL);
        g_hChkEsp = CreateWindowA("BUTTON", " Enable Visuals (Box ESP, Health, Snaplines)", WS_CHILD | BS_AUTOCHECKBOX, 50, 190, 380, 24, hWnd, (HMENU)IDC_CHK_ESP, NULL, NULL);
        g_hChkObs = CreateWindowA("BUTTON", " Stream Proof (OBS / Discord Bypass)", WS_CHILD | BS_AUTOCHECKBOX, 50, 220, 380, 24, hWnd, (HMENU)IDC_CHK_OBS, NULL, NULL);

        g_hBtnFetchVar = CreateWindowA("BUTTON", "Fetch Cloud Offsets", WS_CHILD | BS_PUSHBUTTON, 40, 270, 195, 36, hWnd, (HMENU)IDC_BTN_FETCH_VAR, NULL, NULL);
        g_hBtnInject = CreateWindowA("BUTTON", "Launch / Inject", WS_CHILD | BS_PUSHBUTTON, 255, 270, 195, 36, hWnd, (HMENU)IDC_BTN_INJECT, NULL, NULL);
        g_hBtnLogout = CreateWindowA("BUTTON", "Logout", WS_CHILD | BS_PUSHBUTTON, 40, 320, 410, 32, hWnd, (HMENU)IDC_BTN_LOGOUT, NULL, NULL);

        // Set default font for all controls
        SendMessage(g_hEditUser, WM_SETFONT, (WPARAM)g_hFontBody, TRUE);
        SendMessage(g_hEditPass, WM_SETFONT, (WPARAM)g_hFontBody, TRUE);
        SendMessage(g_hEditKey, WM_SETFONT, (WPARAM)g_hFontBody, TRUE);
        SendMessage(g_hBtnAction, WM_SETFONT, (WPARAM)g_hFontBody, TRUE);
        SendMessage(g_hBtnTab1, WM_SETFONT, (WPARAM)g_hFontBody, TRUE);
        SendMessage(g_hBtnTab2, WM_SETFONT, (WPARAM)g_hFontBody, TRUE);
        SendMessage(g_hBtnTab3, WM_SETFONT, (WPARAM)g_hFontBody, TRUE);
        SendMessage(g_hChkAimbot, WM_SETFONT, (WPARAM)g_hFontBody, TRUE);
        SendMessage(g_hChkEsp, WM_SETFONT, (WPARAM)g_hFontBody, TRUE);
        SendMessage(g_hChkObs, WM_SETFONT, (WPARAM)g_hFontBody, TRUE);
        SendMessage(g_hBtnFetchVar, WM_SETFONT, (WPARAM)g_hFontBody, TRUE);
        SendMessage(g_hBtnInject, WM_SETFONT, (WPARAM)g_hFontBody, TRUE);
        SendMessage(g_hBtnLogout, WM_SETFONT, (WPARAM)g_hFontBody, TRUE);

        SendMessage(g_hChkAimbot, BM_SETCHECK, BST_CHECKED, 0);
        SendMessage(g_hChkEsp, BM_SETCHECK, BST_CHECKED, 0);

        UpdateControlVisibility();

        // Initial connection test
        std::thread([]() {
            std::string initMsg;
            if (g_Auth.Initialize(initMsg)) {
                SetStatus("Connected to RCC AUTH (v" + VERSION + ")", COLOR_GREEN);
            } else {
                SetStatus("Error: " + initMsg, COLOR_RED);
            }
        }).detach();

        return 0;
    }

    case WM_COMMAND: {
        int id = LOWORD(wParam);
        if (id == IDC_TAB_LOGIN) {
            g_LoginTab = 0;
            UpdateControlVisibility();
        } else if (id == IDC_TAB_REGISTER) {
            g_LoginTab = 1;
            UpdateControlVisibility();
        } else if (id == IDC_TAB_KEYONLY) {
            g_LoginTab = 2;
            UpdateControlVisibility();
        } else if (id == IDC_BTN_ACTION) {
            DoAuthAction();
        } else if (id == IDC_BTN_LOGOUT) {
            g_CurrentState = STATE_LOGIN;
            SetStatus("Logged out.", COLOR_MUTED);
            UpdateControlVisibility();
        } else if (id == IDC_BTN_FETCH_VAR) {
            std::thread([]() {
                SetStatus("Fetching offset from RCC AUTH cloud...", COLOR_CYAN);
                std::string val;
                if (g_Auth.GetVariable("dwLocalPlayer", val)) {
                    MessageBoxA(g_hWndMain, ("Retrieved Cloud Variable:\ndwLocalPlayer = " + val).c_str(), "RCC AUTH Cloud Variable", MB_OK | MB_ICONINFORMATION);
                    SetStatus("Cloud offset synchronized: " + val, COLOR_GREEN);
                } else {
                    SetStatus("Variable not found on server.", COLOR_RED);
                }
            }).detach();
        } else if (id == IDC_BTN_INJECT) {
            SetStatus("Payload injected into memory successfully! Enjoy.", COLOR_GREEN);
            MessageBoxA(hWnd, "Cheat / Tool successfully loaded into memory!\nProtection active.", "RCC AUTH Loader", MB_OK | MB_ICONINFORMATION);
        }
        return 0;
    }

    case WM_USER + 1: { // State Changed Message
        UpdateControlVisibility();
        return 0;
    }

    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);

        RECT rc;
        GetClientRect(hWnd, &rc);
        FillRect(hdc, &rc, g_hBrushBg);

        SetBkMode(hdc, TRANSPARENT);

        if (g_CurrentState == STATE_LOGIN) {
            // Title Header
            SelectObject(hdc, g_hFontTitle);
            SetTextColor(hdc, COLOR_CYAN);
            TextOutA(hdc, 40, 20, "RCC AUTH - SECURE LOADER", 24);

            SelectObject(hdc, g_hFontSmall);
            SetTextColor(hdc, COLOR_MUTED);
            TextOutA(hdc, 40, 46, "ENTER YOUR CREDENTIALS OR LICENSE KEY", 37);

            // Labels
            SelectObject(hdc, g_hFontBody);
            SetTextColor(hdc, COLOR_TEXT);

            if (g_LoginTab == 0) {
                TextOutA(hdc, 40, 115, "Username:", 9);
                TextOutA(hdc, 40, 175, "Password:", 9);
            } else if (g_LoginTab == 1) {
                TextOutA(hdc, 40, 115, "Username:", 9);
                TextOutA(hdc, 40, 175, "Password:", 9);
                TextOutA(hdc, 40, 235, "License Key (RCC-XXXX-XXXX):", 29);
            } else {
                TextOutA(hdc, 40, 235, "License Key (RCC-XXXX-XXXX):", 29);
            }
        } else {
            // Main Dashboard Header
            SelectObject(hdc, g_hFontTitle);
            SetTextColor(hdc, COLOR_CYAN);
            TextOutA(hdc, 40, 20, "RCC AUTH - MAIN DASHBOARD", 25);

            // User Info Box
            RECT cardRc = { 40, 55, 450, 140 };
            FillRect(hdc, &cardRc, g_hBrushCard);
            FrameRect(hdc, &cardRc, (HBRUSH)GetStockObject(GRAY_BRUSH));

            SelectObject(hdc, g_hFontBody);
            SetTextColor(hdc, COLOR_TEXT);
            std::string userLine = "Welcome, " + g_Auth.user.username + " (Rank: Level " + std::to_string(g_Auth.user.rank) + ")";
            TextOutA(hdc, 55, 68, userLine.c_str(), (int)userLine.length());

            SelectObject(hdc, g_hFontSmall);
            SetTextColor(hdc, COLOR_MUTED);
            std::string expLine = "Expiration: " + (g_Auth.user.expiresAt.empty() ? "Lifetime" : g_Auth.user.expiresAt);
            TextOutA(hdc, 55, 92, expLine.c_str(), (int)expLine.length());

            std::string hwidLine = "HWID: " + g_Auth.user.hwid.substr(0, 24) + "...";
            TextOutA(hdc, 55, 112, hwidLine.c_str(), (int)hwidLine.length());
        }

        // Status Bar at Bottom
        SelectObject(hdc, g_hFontSmall);
        SetTextColor(hdc, g_StatusColor);
        TextOutA(hdc, 40, 365, g_StatusText.c_str(), (int)g_StatusText.length());

        EndPaint(hWnd, &ps);
        return 0;
    }

    case WM_CTLCOLORSTATIC: {
        HDC hdcStatic = (HDC)wParam;
        SetTextColor(hdcStatic, COLOR_TEXT);
        SetBkColor(hdcStatic, COLOR_BG);
        return (INT_PTR)g_hBrushBg;
    }

    case WM_DESTROY: {
        DeleteObject(g_hBrushBg);
        DeleteObject(g_hBrushCard);
        DeleteObject(g_hFontTitle);
        DeleteObject(g_hFontBody);
        DeleteObject(g_hFontSmall);
        PostQuitMessage(0);
        return 0;
    }
    }
    return DefWindowProcA(hWnd, msg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    InitCommonControls();

    WNDCLASSA wc = { 0 };
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = "RCCAuthAppClass";
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);

    RegisterClassA(&wc);

    int w = 500, h = 430;
    int x = (GetSystemMetrics(SM_CXSCREEN) - w) / 2;
    int y = (GetSystemMetrics(SM_CYSCREEN) - h) / 2;

    g_hWndMain = CreateWindowA(
        "RCCAuthAppClass",
        "RCC AUTH - Client Application Demo",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
        x, y, w, h,
        NULL, NULL, hInstance, NULL
    );

    if (!g_hWndMain) return 0;

    ShowWindow(g_hWndMain, nCmdShow);
    UpdateWindow(g_hWndMain);

    MSG msg;
    while (GetMessageA(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessageA(&msg);
    }

    return (int)msg.wParam;
}
