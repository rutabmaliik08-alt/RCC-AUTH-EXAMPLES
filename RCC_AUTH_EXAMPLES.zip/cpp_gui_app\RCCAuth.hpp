#pragma once

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <wininet.h>
#include <wincrypt.h>
#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <iomanip>

#pragma comment(lib, "wininet.lib")
#pragma comment(lib, "crypt32.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "comctl32.lib")

namespace RCCAuthSDK {

    struct UserProfile {
        std::string username;
        std::string hwid;
        int rank = 1;
        std::string expiresAt;
        long long remainingSeconds = -1;
    };

    class RCCAuth {
    private:
        std::string m_serverUrl;
        std::string m_appName;
        std::string m_appSecret;
        std::string m_version;
        std::string m_sessionId;
        bool m_initialized = false;

    public:
        UserProfile user;

        RCCAuth(const std::string& serverUrl, const std::string& appName, const std::string& appSecret, const std::string& version)
            : m_serverUrl(serverUrl), m_appName(appName), m_appSecret(appSecret), m_version(version) {}

        // -------------------------------------------------------------
        // HWID Generator using Native Windows APIs
        // -------------------------------------------------------------
        static std::string GetHWID() {
            char computerName[MAX_COMPUTERNAME_LENGTH + 1];
            DWORD size = sizeof(computerName);
            GetComputerNameA(computerName, &size);

            DWORD volumeSerial = 0;
            GetVolumeInformationA("C:\\", NULL, 0, &volumeSerial, NULL, NULL, NULL, 0);

            std::stringstream ss;
            ss << computerName << "-" << volumeSerial;
            return Sha256(ss.str());
        }

        // -------------------------------------------------------------
        // SHA-256 Hashing via WinCrypt
        // -------------------------------------------------------------
        static std::string Sha256(const std::string& input) {
            HCRYPTPROV hProv = 0;
            HCRYPTHASH hHash = 0;
            BYTE hash[32];
            DWORD cbHash = 32;
            std::stringstream ss;

            if (CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_AES, CRYPT_VERIFYCONTEXT)) {
                if (CryptCreateHash(hProv, CALG_SHA_256, 0, 0, &hHash)) {
                    if (CryptHashData(hHash, (BYTE*)input.c_str(), (DWORD)input.length(), 0)) {
                        if (CryptGetHashParam(hHash, HP_HASHVAL, hash, &cbHash, 0)) {
                            for (DWORD i = 0; i < cbHash; i++) {
                                ss << std::hex << std::setw(2) << std::setfill('0') << (int)hash[i];
                            }
                        }
                    }
                    CryptDestroyHash(hHash);
                }
                CryptReleaseContext(hProv, 0);
            }
            return ss.str();
        }

        // -------------------------------------------------------------
        // HTTP POST via WinINet
        // -------------------------------------------------------------
        bool HttpPost(const std::string& endpoint, const std::string& jsonPayload, std::string& responseOut) {
            HINTERNET hInternet = InternetOpenA("RCCAuth-Cpp-GUI/1.0", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
            if (!hInternet) return false;

            std::string host = "127.0.0.1";
            INTERNET_PORT port = 3000;
            std::string path = endpoint;

            std::string url = m_serverUrl;
            size_t protocolPos = url.find("://");
            if (protocolPos != std::string::npos) {
                url = url.substr(protocolPos + 3);
            }
            size_t colonPos = url.find(':');
            size_t slashPos = url.find('/');
            if (colonPos != std::string::npos) {
                host = url.substr(0, colonPos);
                if (slashPos != std::string::npos) {
                    port = (INTERNET_PORT)std::stoi(url.substr(colonPos + 1, slashPos - colonPos - 1));
                } else {
                    port = (INTERNET_PORT)std::stoi(url.substr(colonPos + 1));
                }
            } else if (slashPos != std::string::npos) {
                host = url.substr(0, slashPos);
            } else {
                host = url;
            }

            HINTERNET hConnect = InternetConnectA(hInternet, host.c_str(), port, NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
            if (!hConnect) {
                InternetCloseHandle(hInternet);
                return false;
            }

            DWORD flags = INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE;
            HINTERNET hRequest = HttpOpenRequestA(hConnect, "POST", path.c_str(), NULL, NULL, NULL, flags, 0);
            if (!hRequest) {
                InternetCloseHandle(hConnect);
                InternetCloseHandle(hInternet);
                return false;
            }

            std::string headers = "Content-Type: application/json\r\nx-app-secret: " + m_appSecret + "\r\n";
            BOOL sent = HttpSendRequestA(hRequest, headers.c_str(), (DWORD)headers.length(), (LPVOID)jsonPayload.c_str(), (DWORD)jsonPayload.length());

            if (sent) {
                char buffer[4096];
                DWORD bytesRead = 0;
                std::stringstream respStream;
                while (InternetReadFile(hRequest, buffer, sizeof(buffer) - 1, &bytesRead) && bytesRead > 0) {
                    buffer[bytesRead] = '\0';
                    respStream << buffer;
                }
                responseOut = respStream.str();
            }

            InternetCloseHandle(hRequest);
            InternetCloseHandle(hConnect);
            InternetCloseHandle(hInternet);
            return sent != FALSE;
        }

        // -------------------------------------------------------------
        // JSON Helper Parser
        // -------------------------------------------------------------
        static std::string ExtractJsonString(const std::string& json, const std::string& key) {
            std::string search = "\"" + key + "\":\"";
            size_t start = json.find(search);
            if (start == std::string::npos) {
                search = "\"" + key + "\":";
                start = json.find(search);
                if (start == std::string::npos) return "";
                start += search.length();
                size_t end = json.find_first_of(",}", start);
                return json.substr(start, end - start);
            }
            start += search.length();
            size_t end = json.find("\"", start);
            return json.substr(start, end - start);
        }

        static bool ExtractJsonBool(const std::string& json, const std::string& key) {
            std::string search = "\"" + key + "\":true";
            return json.find(search) != std::string::npos;
        }

        // -------------------------------------------------------------
        // API Methods
        // -------------------------------------------------------------
        bool Initialize(std::string& message) {
            std::stringstream json;
            json << "{\"name\":\"" << m_appName << "\",\"secret\":\"" << m_appSecret << "\",\"version\":\"" << m_version << "\"}";

            std::string response;
            if (!HttpPost("/api/v1/init", json.str(), response)) {
                message = "Failed to connect to RCC AUTH Server.";
                return false;
            }

            if (ExtractJsonBool(response, "success")) {
                m_initialized = true;
                m_sessionId = ExtractJsonString(response, "session_id");
                message = ExtractJsonString(response, "message");
                return true;
            }

            message = ExtractJsonString(response, "message");
            return false;
        }

        bool Login(const std::string& username, const std::string& password, std::string& message) {
            if (!m_initialized) {
                if (!Initialize(message)) return false;
            }

            std::stringstream json;
            json << "{\"secret\":\"" << m_appSecret << "\",\"username\":\"" << username << "\",\"password\":\"" << password << "\",\"hwid\":\"" << GetHWID() << "\"}";

            std::string response;
            if (!HttpPost("/api/v1/login", json.str(), response)) {
                message = "Server connection lost.";
                return false;
            }

            if (ExtractJsonBool(response, "success")) {
                user.username = username;
                user.hwid = GetHWID();
                user.expiresAt = ExtractJsonString(response, "expires_at");
                message = ExtractJsonString(response, "message");
                return true;
            }

            message = ExtractJsonString(response, "message");
            return false;
        }

        bool Register(const std::string& username, const std::string& password, const std::string& licenseKey, std::string& message) {
            if (!m_initialized) {
                if (!Initialize(message)) return false;
            }

            std::stringstream json;
            json << "{\"secret\":\"" << m_appSecret << "\",\"username\":\"" << username << "\",\"password\":\"" << password << "\",\"license_key\":\"" << licenseKey << "\",\"hwid\":\"" << GetHWID() << "\"}";

            std::string response;
            if (!HttpPost("/api/v1/register", json.str(), response)) {
                message = "Server connection lost.";
                return false;
            }

            if (ExtractJsonBool(response, "success")) {
                user.username = username;
                user.hwid = GetHWID();
                user.expiresAt = ExtractJsonString(response, "expires_at");
                message = ExtractJsonString(response, "message");
                return true;
            }

            message = ExtractJsonString(response, "message");
            return false;
        }

        bool LicenseAuth(const std::string& licenseKey, std::string& message) {
            if (!m_initialized) {
                if (!Initialize(message)) return false;
            }

            std::stringstream json;
            json << "{\"secret\":\"" << m_appSecret << "\",\"license_key\":\"" << licenseKey << "\",\"hwid\":\"" << GetHWID() << "\"}";

            std::string response;
            if (!HttpPost("/api/v1/license", json.str(), response)) {
                message = "Server connection lost.";
                return false;
            }

            if (ExtractJsonBool(response, "success")) {
                user.username = licenseKey;
                user.hwid = GetHWID();
                user.expiresAt = ExtractJsonString(response, "expires_at");
                message = ExtractJsonString(response, "message");
                return true;
            }

            message = ExtractJsonString(response, "message");
            return false;
        }

        bool GetVariable(const std::string& varName, std::string& valueOut) {
            std::stringstream json;
            json << "{\"secret\":\"" << m_appSecret << "\",\"var_name\":\"" << varName << "\"}";

            std::string response;
            if (!HttpPost("/api/v1/var", json.str(), response)) return false;

            if (ExtractJsonBool(response, "success")) {
                valueOut = ExtractJsonString(response, "var_value");
                return true;
            }
            return false;
        }
    };
}
