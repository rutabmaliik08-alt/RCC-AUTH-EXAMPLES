﻿#pragma once
#include <string>

// -------------------------------------------------------------
// skCrypt - Compile-time String Obfuscation Header for C++
// -------------------------------------------------------------
namespace skc {
    template <int N>
    struct CompileTimeRandom {
        static constexpr unsigned int value = 0x5A1F7B9C ^ (N * 0x45D9F3B);
    };

    template <size_t N, unsigned int Key>
    class EncryptedString {
    private:
        char m_data[N];
    public:
        constexpr EncryptedString(const char* str) : m_data{} {
            for (size_t i = 0; i < N; ++i) {
                m_data[i] = str[i] ^ (char)((Key + i) & 0xFF);
            }
        }

        std::string decrypt() const {
            std::string decrypted;
            decrypted.resize(N - 1);
            for (size_t i = 0; i < N - 1; ++i) {
                decrypted[i] = m_data[i] ^ (char)((Key + i) & 0xFF);
            }
            return decrypted;
        }
    };
}

#define skCrypt(str) []() -> std::string { \
    constexpr size_t len = sizeof(str); \
    constexpr unsigned int key = skc::CompileTimeRandom<__LINE__>::value; \
    static const skc::EncryptedString<len, key> enc(str); \
    return enc.decrypt(); \
}()
