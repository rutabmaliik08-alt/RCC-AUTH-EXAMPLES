"""
RCC AUTH - Discord Bot Integration Example (Python discord.py)
Features:
 - /genkey (Generate license keys)
 - /checkkey (Check license info)
 - /resethwid (1-Click user HWID reset)
 - /userinfo (Inspect user account details)
 - /banuser (Ban user from application)
 - /extend (Add days to user subscription)
"""

import discord
from discord import app_commands
from discord.ext import commands
import requests

# CONFIGURATION
DISCORD_BOT_TOKEN = "YOUR_DISCORD_BOT_TOKEN"
RCC_SERVER_URL    = "http://localhost:3000"
RCC_SELLER_KEY    = "YOUR_SELLER_API_KEY" # Get from /dashboard/api

intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)

def get_headers():
    return {
        "Content-Type": "application/json",
        "x-seller-key": RCC_SELLER_KEY
    }

@bot.event
async def on_ready():
    print(f"[+] RCC AUTH Python Bot online as {bot.user}!")
    try:
        synced = await bot.tree.sync()
        print(f"[+] Synced {len(synced)} slash commands.")
    except Exception as e:
        print(f"[!] Command sync error: {e}")

# 1. /genkey
@bot.tree.command(name="genkey", description="Generate a new license key")
@app_commands.describe(days="Duration in days (-1 for lifetime)", level="Access rank level (1-3)", note="Key note")
async def genkey(interaction: discord.Interaction, days: int = 30, level: int = 1, note: str = "Discord Bot"):
    await interaction.response.defer(ephemeral=True)
    url = f"{RCC_SERVER_URL}/api/v1/seller/key/generate"
    payload = {"count": 1, "duration_days": days, "level": level, "note": note}
    
    try:
        r = requests.post(url, json=payload, headers=get_headers(), timeout=10).json()
        if r.get("success"):
            key = r["keys"][0]
            embed = discord.Embed(title="🔑 License Key Generated", color=0x06B6D4)
            embed.add_field(name="License Key", value=f"`{key}`", inline=False)
            embed.add_field(name="Duration", value=f"{days} Days" if days != -1 else "Lifetime", inline=True)
            embed.add_field(name="Rank Level", value=f"Level {level}", inline=True)
            await interaction.followup.send(embed=embed)
        else:
            await interaction.followup.send(f"❌ Error: {r.get('message')}")
    except Exception as e:
        await interaction.followup.send(f"❌ Network Error: {e}")

# 2. /resethwid
@bot.tree.command(name="resethwid", description="Reset HWID lock for a user")
@app_commands.describe(username="Registered username")
async def resethwid(interaction: discord.Interaction, username: str):
    await interaction.response.defer(ephemeral=True)
    url = f"{RCC_SERVER_URL}/api/v1/seller/user/hwid_reset"
    payload = {"username": username}

    try:
        r = requests.post(url, json=payload, headers=get_headers(), timeout=10).json()
        if r.get("success"):
            embed = discord.Embed(title="🔄 HWID Reset Successful", description=r.get("message"), color=0x10B981)
            await interaction.followup.send(embed=embed)
        else:
            await interaction.followup.send(f"❌ Error: {r.get('message')}")
    except Exception as e:
        await interaction.followup.send(f"❌ Error: {e}")

# 3. /checkkey
@bot.tree.command(name="checkkey", description="Inspect a license key status")
@app_commands.describe(key="License key to inspect")
async def checkkey(interaction: discord.Interaction, key: str):
    await interaction.response.defer(ephemeral=True)
    url = f"{RCC_SERVER_URL}/api/v1/seller/key/info?key={key}"

    try:
        r = requests.get(url, headers=get_headers(), timeout=10).json()
        if r.get("success"):
            lic = r["license"]
            embed = discord.Embed(title="📋 License Key Details", color=0x10B981 if lic["status"] == "unused" else 0x6366F1)
            embed.add_field(name="Key", value=f"`{lic['key']}`", inline=False)
            embed.add_field(name="Status", value=lic["status"].upper(), inline=True)
            embed.add_field(name="Duration", value=str(lic["duration_days"]), inline=True)
            embed.add_field(name="Used By", value=lic["used_by"] or "None", inline=True)
            await interaction.followup.send(embed=embed)
        else:
            await interaction.followup.send(f"❌ Error: {r.get('message')}")
    except Exception as e:
        await interaction.followup.send(f"❌ Error: {e}")

# 4. /userinfo
@bot.tree.command(name="userinfo", description="Look up user profile, rank, and expiration")
@app_commands.describe(username="Target username")
async def userinfo(interaction: discord.Interaction, username: str):
    await interaction.response.defer(ephemeral=True)
    url = f"{RCC_SERVER_URL}/api/v1/seller/user/info?username={username}"

    try:
        r = requests.get(url, headers=get_headers(), timeout=10).json()
        if r.get("success"):
            u = r["user"]
            embed = discord.Embed(title=f"👤 User Info: {u['username']}", color=0xF43F5E if u["is_banned"] else 0x06B6D4)
            embed.add_field(name="Rank", value=f"Level {u['rank']}", inline=True)
            embed.add_field(name="Expires", value=str(u["expires_at"]), inline=True)
            embed.add_field(name="Banned", value="Yes" if u["is_banned"] else "No", inline=True)
            embed.add_field(name="HWID Lock", value=f"`{u['hwid']}`", inline=False)
            await interaction.followup.send(embed=embed)
        else:
            await interaction.followup.send(f"❌ Error: {r.get('message')}")
    except Exception as e:
        await interaction.followup.send(f"❌ Error: {e}")

if __name__ == "__main__":
    if DISCORD_BOT_TOKEN != "YOUR_DISCORD_BOT_TOKEN":
        bot.run(DISCORD_BOT_TOKEN)
    else:
        print("[!] Please set your DISCORD_BOT_TOKEN and RCC_SELLER_KEY to run.")
