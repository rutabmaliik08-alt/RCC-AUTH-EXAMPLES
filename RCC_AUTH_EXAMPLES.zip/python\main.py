import os
import sys
from rccauth import api

# =========================================================================
# RCC AUTH Python Configuration (Configure with your Dashboard App Credentials)
# =========================================================================
rcc_name     = "RCC_INTERNAL+EXTERNAL"
rcc_ownerid  = "RCC_46"
rcc_secret   = "RCCSec_0ef6101773f71c35c57ae205"
rcc_version  = "1.0.0"
rcc_url      = "https://white-owl-688321.hostingersite.com/api/v1/"

# Initialize RCC Auth Client
app = api(rcc_name, rcc_ownerid, rcc_secret, rcc_version, rcc_url)

def print_user_info():
    print("\n============================================")
    print(" [SUCCESS] Authenticated Successfully!")
    print("============================================")
    print(f" Username:     {app.data.username}")
    print(f" IP Address:   {app.data.ip}")
    print(f" HWID Lock:    {app.data.hwid}")
    print(f" Subscription: {app.data.subscription}")
    print(f" Expiry Date:  {app.data.expiry}")
    print(f" Rank Level:   {app.data.rank}")
    print(f" Created Date: {app.data.createdate}")
    print("============================================\n")

    # Example Cloud Variable Read
    secret_var = app.var("game_offset")
    if secret_var:
        print(f" [*] Cloud Variable [game_offset]: {secret_var}")

    # Example Audit Log
    app.log(f"User {app.data.username} logged into Python Client")
    print(" [*] Sent session audit log to server.\n")

def main():
    print("============================================")
    print("      RCC AUTH PYTHON MODERN SDK v2.0       ")
    print("============================================")
    print(" [*] Initializing connection to server...")

    app.init()

    if not app.response.success:
        print(f" [-] Initialization Failed: {app.response.message}")
        input("Press Enter to exit...")
        return

    print(f" [+] Handshake Initialized: {app.response.message}\n")

    while True:
        print(" Select an Authentication Option:")
        print(" [1] Login with Username & Password")
        print(" [2] Register with License Key")
        print(" [3] License Key Only Authentication")
        print(" [4] Exit")
        choice = input(" Choose [1-4]: ").strip()

        if choice == "1":
            user = input(" Enter Username: ").strip()
            password = input(" Enter Password: ").strip()
            print(" [*] Logging in...")
            app.login(user, password)

            if app.response.success:
                print_user_info()
                break
            else:
                print(f" [-] Login Failed: {app.response.message}\n")

        elif choice == "2":
            user = input(" Enter Desired Username: ").strip()
            password = input(" Enter Password: ").strip()
            key = input(" Enter License Key: ").strip()
            print(" [*] Registering account...")
            app.regstr(user, password, key)

            if app.response.success:
                print_user_info()
                break
            else:
                print(f" [-] Registration Failed: {app.response.message}\n")

        elif choice == "3":
            key = input(" Enter License Key: ").strip()
            print(" [*] Authenticating License Key...")
            app.license(key)

            if app.response.success:
                print_user_info()
                break
            else:
                print(f" [-] License Check Failed: {app.response.message}\n")

        elif choice == "4":
            sys.exit(0)
        else:
            print(" Invalid option. Please choose 1-4.\n")

    input("Press Enter to exit...")

if __name__ == "__main__":
    main()
