import sys
import os
from rccauth import api

# =========================================================================
# RCC AUTH Client Credentials (RCC AUTH Architecture)
# =========================================================================
name = "RCCLoader"                             # App name
ownerid = "RCC_Dev1"                           # Account ID
secret = "RCCSec_9f83a12b4e76c5d9"             # Application secret
version = "1.0.0"                              # Application version
url = "http://127.0.0.1:3000/api/v1/"          # Server URL
path = ""                                      # (OPTIONAL)

# Initialize Client API
RCCAuthApp = api(name, ownerid, secret, version, url, path)

def main():
    print("""
   ___    ___   ___      ___  __  __ _____ _  _ 
  | _ \\  / __| / __|    /   \\|  ||  |_   _| || |
  |   / | (__ | (__    / _ \\ |  ||  | | | | __ |
  |_|_\\  \\___| \\___|  /_/ \\_\\ \\______/ |_| |_||_|
        Python 3 Client SDK (RCC AUTH Standard)
====================================================
""")

    print(f"[*] Initializing connection to {url}...")
    print(f"[*] Machine HWID: {api.get_hwid()}")

    RCCAuthApp.init()

    if not RCCAuthApp.response.success:
        print(f"[!] Init failed: {RCCAuthApp.response.message}")
        input("\nPress enter to exit...")
        sys.exit(1)

    print(f"[+] {RCCAuthApp.response.message}")

    while True:
        print("\nChoose Option:")
        print(" [1] Login (User & Pass)")
        print(" [2] Register (User, Pass & Key)")
        print(" [3] License Only Auth")
        print(" [4] Exit")
        
        choice = input("Choice > ").strip()

        if choice == "1":
            user = input("Username: ")
            password = input("Password: ")
            
            print("[*] Authenticating...")
            RCCAuthApp.login(user, password)
            
            if RCCAuthApp.response.success:
                print("\n[+] Login Successful!")
                print(f"User: {RCCAuthApp.data.username} | HWID: {RCCAuthApp.data.hwid}")
                print(f"Subscription: {RCCAuthApp.data.subscription}")
            else:
                print(f"[!] Login failed: {RCCAuthApp.response.message}")

        elif choice == "2":
            user = input("Username: ")
            password = input("Password: ")
            key = input("License Key: ")
            
            print("[*] Registering...")
            RCCAuthApp.regstr(user, password, key)
            
            if RCCAuthApp.response.success:
                print("\n[+] Registered Successfully!")
                print(f"User: {RCCAuthApp.data.username} | Rank: {RCCAuthApp.data.rank}")
            else:
                print(f"[!] Register failed: {RCCAuthApp.response.message}")

        elif choice == "3":
            key = input("License Key: ")
            
            print("[*] Verifying Key...")
            RCCAuthApp.license(key)
            
            if RCCAuthApp.response.success:
                print("\n[+] License Valid! Welcome.")
                print(f"Subscription: {RCCAuthApp.data.subscription}")
                
                # Fetch cloud variable example
                offset = RCCAuthApp.var("dwLocalPlayer")
                if offset:
                    print(f"[+] Cloud Variable dwLocalPlayer: {offset}")
            else:
                print(f"[!] License failed: {RCCAuthApp.response.message}")

        elif choice == "4":
            break

if __name__ == "__main__":
    main()
