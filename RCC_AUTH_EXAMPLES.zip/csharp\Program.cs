using System;
using RCCAuthSDK;

namespace RCCAuthDemo
{
    internal class Program
    {
        // =========================================================================
        // RCC AUTH C# Configuration (Configure with your Dashboard App Credentials)
        // =========================================================================
        private static readonly string rcc_name    = "RCC_INTERNAL+EXTERNAL";
        private static readonly string rcc_ownerid = "RCC_46";
        private static readonly string rcc_secret  = "RCCSec_0ef6101773f71c35c57ae205";
        private static readonly string rcc_version = "1.0.0";
        private static readonly string rcc_url     = "https://white-owl-688321.hostingersite.com/api/v1/";

        private static readonly api App = new api(rcc_name, rcc_ownerid, rcc_secret, rcc_version, rcc_url);

        static void Main(string[] args)
        {
            Console.Title = "RCC AUTH C# .NET Client Demonstration";

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("============================================");
            Console.WriteLine("       RCC AUTH C# MODERN SDK v2.0          ");
            Console.WriteLine("============================================");
            Console.ResetColor();

            Console.WriteLine(" [*] Initializing connection to server...");
            App.init();

            if (!App.response.success)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($" [-] Initialization Failed: {App.response.message}");
                Console.ResetColor();
                Console.WriteLine("Press any key to exit...");
                Console.ReadKey();
                return;
            }

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($" [+] Handshake Initialized: {App.response.message}\n");
            Console.ResetColor();

            while (true)
            {
                Console.WriteLine(" Select an Authentication Option:");
                Console.WriteLine(" [1] Login with Username & Password");
                Console.WriteLine(" [2] Register with License Key");
                Console.WriteLine(" [3] License Key Only Authentication");
                Console.WriteLine(" [4] Exit");
                Console.Write(" Choose [1-4]: ");

                string? choice = Console.ReadLine()?.Trim();

                if (choice == "1")
                {
                    Console.Write(" Enter Username: ");
                    string user = Console.ReadLine() ?? "";
                    Console.Write(" Enter Password: ");
                    string pass = Console.ReadLine() ?? "";

                    Console.WriteLine(" [*] Logging in...");
                    App.login(user, pass);

                    if (App.response.success)
                    {
                        PrintUserInfo();
                        break;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine($" [-] Login Failed: {App.response.message}\n");
                        Console.ResetColor();
                    }
                }
                else if (choice == "2")
                {
                    Console.Write(" Enter Desired Username: ");
                    string user = Console.ReadLine() ?? "";
                    Console.Write(" Enter Password: ");
                    string pass = Console.ReadLine() ?? "";
                    Console.Write(" Enter License Key: ");
                    string key = Console.ReadLine() ?? "";

                    Console.WriteLine(" [*] Registering account...");
                    App.regstr(user, pass, key);

                    if (App.response.success)
                    {
                        PrintUserInfo();
                        break;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine($" [-] Registration Failed: {App.response.message}\n");
                        Console.ResetColor();
                    }
                }
                else if (choice == "3")
                {
                    Console.Write(" Enter License Key: ");
                    string key = Console.ReadLine() ?? "";

                    Console.WriteLine(" [*] Authenticating License Key...");
                    App.license(key);

                    if (App.response.success)
                    {
                        PrintUserInfo();
                        break;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine($" [-] License Check Failed: {App.response.message}\n");
                        Console.ResetColor();
                    }
                }
                else if (choice == "4")
                {
                    return;
                }
                else
                {
                    Console.WriteLine(" Invalid option. Please select 1-4.\n");
                }
            }

            Console.WriteLine(" Press any key to exit application...");
            Console.ReadKey();
        }

        private static void PrintUserInfo()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n============================================");
            Console.WriteLine(" [SUCCESS] Authenticated Successfully!");
            Console.WriteLine("============================================");
            Console.ResetColor();

            Console.WriteLine($" Username:     {App.data.username}");
            Console.WriteLine($" IP Address:   {App.data.ip}");
            Console.WriteLine($" HWID Lock:    {App.data.hwid}");
            Console.WriteLine($" Subscription: {App.data.subscription}");
            Console.WriteLine($" Expiry Date:  {App.data.expiry}");
            Console.WriteLine($" Rank Level:   {App.data.rank}");
            Console.WriteLine($" Created Date: {App.data.createdate}");
            Console.WriteLine("============================================\n");

            // Example Cloud Variable Read
            string secretVar = App.var("game_offset");
            if (!string.IsNullOrEmpty(secretVar))
            {
                Console.WriteLine($" [*] Cloud Variable [game_offset]: {secretVar}");
            }

            // Example Audit Log
            App.log($"User {App.data.username} logged into C# Client");
            Console.WriteLine(" [*] Logged session audit event to server.\n");
        }
    }
}
