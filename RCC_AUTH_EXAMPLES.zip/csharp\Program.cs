using System;
using RCCAuthSDK;

class Program
{
    // =========================================================================
    // RCC AUTH Client Credentials (RCC AUTH Architecture)
    // =========================================================================
    static string name = "RCCLoader";
    static string ownerid = "RCC_Dev1";
    static string secret = "RCCSec_9f83a12b4e76c5d9";
    static string version = "1.0.0";
    static string url = "http://127.0.0.1:3000/api/v1/";
    static string path = "";

    public static api RCCAuthApp = new api(name, ownerid, secret, version, url, path);

    static void Main()
    {
        Console.Title = "RCC AUTH C# .NET Client SDK Example";
        Console.ForegroundColor = ConsoleColor.Cyan;

        Console.WriteLine(@"
   ___    ___   ___      ___  __  __ _____ _  _ 
  | _ \  / __| / __|    /   \|  ||  |_   _| || |
  |   / | (__ | (__    / _ \ |  ||  | | | | __ |
  |_|_\  \___| \___|  /_/ \_\ \______/ |_| |_||_|
        C# .NET Client SDK (RCC AUTH Standard)
====================================================
");
        Console.ResetColor();

        Console.WriteLine($"[*] Initializing connection to {url}...");
        Console.WriteLine($"[*] Machine HWID: {api.GetHWID()}");

        RCCAuthApp.init();

        if (!RCCAuthApp.response.success)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"[!] Init Failed: {RCCAuthApp.response.message}");
            Console.ResetColor();
            Console.ReadKey();
            return;
        }

        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine($"[+] {RCCAuthApp.response.message}");
        Console.ResetColor();

        while (true)
        {
            Console.WriteLine("\nChoose Option:");
            Console.WriteLine(" [1] Login (User & Pass)");
            Console.WriteLine(" [2] Register (User, Pass & Key)");
            Console.WriteLine(" [3] License Only Auth");
            Console.WriteLine(" [4] Exit");
            Console.Write("Choice > ");

            string choice = Console.ReadLine()?.Trim() ?? "";

            if (choice == "1")
            {
                Console.Write("Username: "); string user = Console.ReadLine() ?? "";
                Console.Write("Password: "); string pass = Console.ReadLine() ?? "";

                Console.WriteLine("[*] Authenticating...");
                RCCAuthApp.login(user, pass);

                if (RCCAuthApp.response.success)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("\n[+] Login Successful!");
                    Console.WriteLine($"User: {RCCAuthApp.data.username} | HWID: {RCCAuthApp.data.hwid}");
                    Console.WriteLine($"Subscription: {RCCAuthApp.data.subscription}");
                    Console.ResetColor();
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"[!] Login failed: {RCCAuthApp.response.message}");
                    Console.ResetColor();
                }
            }
            else if (choice == "2")
            {
                Console.Write("Username: "); string user = Console.ReadLine() ?? "";
                Console.Write("Password: "); string pass = Console.ReadLine() ?? "";
                Console.Write("License Key: "); string key = Console.ReadLine() ?? "";

                Console.WriteLine("[*] Registering...");
                RCCAuthApp.regstr(user, pass, key);

                if (RCCAuthApp.response.success)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("\n[+] Registered Successfully!");
                    Console.WriteLine($"User: {RCCAuthApp.data.username} | Rank: {RCCAuthApp.data.rank}");
                    Console.ResetColor();
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"[!] Register failed: {RCCAuthApp.response.message}");
                    Console.ResetColor();
                }
            }
            else if (choice == "3")
            {
                Console.Write("License Key: "); string key = Console.ReadLine() ?? "";

                Console.WriteLine("[*] Authenticating Key...");
                RCCAuthApp.license(key);

                if (RCCAuthApp.response.success)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("\n[+] License Valid! Welcome.");
                    Console.WriteLine($"Subscription: {RCCAuthApp.data.subscription}");
                    Console.ResetColor();

                    string offset = RCCAuthApp.var("dwLocalPlayer");
                    if (!string.IsNullOrEmpty(offset))
                    {
                        Console.WriteLine($"[+] Cloud Var dwLocalPlayer: {offset}");
                    }
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"[!] License failed: {RCCAuthApp.response.message}");
                    Console.ResetColor();
                }
            }
            else if (choice == "4")
            {
                break;
            }
        }
    }
}
