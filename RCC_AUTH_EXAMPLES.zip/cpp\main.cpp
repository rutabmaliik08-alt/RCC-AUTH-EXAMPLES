#include <iostream>
#include <string>
#include "RCCAuth.hpp"

// =========================================================================
// RCC AUTH Client Configuration (Configure with your Dashboard App Credentials)
// =========================================================================
static std::string rcc_name     = skCrypt("RCC_INTERNAL+EXTERNAL");
static std::string rcc_ownerid  = skCrypt("RCC_46");
static std::string rcc_secret   = skCrypt("RCCSec_0ef6101773f71c35c57ae205");
static std::string rcc_version  = skCrypt("1.0.0");
static std::string rcc_url      = skCrypt("https://white-owl-688321.hostingersite.com/api/v1/");

// Initialize RCC Auth Client
inline RCCAuthSDK::api App(rcc_name, rcc_ownerid, rcc_secret, rcc_version, rcc_url);

void print_user_info() {
    std::cout << "\n============================================\n";
    std::cout << " [SUCCESS] Authenticated Successfully!\n";
    std::cout << "============================================\n";
    std::cout << " Username:     " << App.data.username << "\n";
    std::cout << " IP Address:   " << App.data.ip << "\n";
    std::cout << " HWID Lock:    " << App.data.hwid << "\n";
    std::cout << " Subscription: " << App.data.subscription << "\n";
    std::cout << " Expiry Date:  " << (App.data.expiry.empty() ? "Lifetime" : App.data.expiry) << "\n";
    std::cout << " Rank Level:   " << App.data.rank << "\n";
    std::cout << " Created Date: " << App.data.createdate << "\n";
    std::cout << "============================================\n\n";

    // Example Cloud Variable Read
    std::string secretOffset = App.var("game_offset");
    if (!secretOffset.empty()) {
        std::cout << " [*] Fetched Cloud Variable [game_offset]: " << secretOffset << "\n";
    }

    // Example Audit Log
    App.log("User " + App.data.username + " started client session.");
    std::cout << " [*] Sent session audit log to server.\n";
}

int main() {
    SetConsoleTitleA("RCC AUTH C++ Client Demonstration");

    std::cout << "============================================\n";
    std::cout << "        RCC AUTH C++ MODERN SDK v2.0        \n";
    std::cout << "============================================\n";
    std::cout << " [*] Initializing connection to server...\n";

    App.init();

    if (!App.response.success) {
        std::cout << " [-] Initialization Failed: " << App.response.message << "\n";
        system("pause");
        return 1;
    }

    std::cout << " [+] Handshake Initialized: " << App.response.message << "\n\n";

    while (true) {
        std::cout << " Select an Authentication Option:\n";
        std::cout << " [1] Login with Username & Password\n";
        std::cout << " [2] Register with License Key\n";
        std::cout << " [3] License Key Only Authentication\n";
        std::cout << " [4] Exit\n";
        std::cout << " Choose [1-4]: ";

        int choice = 0;
        std::cin >> choice;

        if (choice == 1) {
            std::string user, pass;
            std::cout << " Enter Username: ";
            std::cin >> user;
            std::cout << " Enter Password: ";
            std::cin >> pass;

            std::cout << " [*] Logging in...\n";
            App.login(user, pass);

            if (App.response.success) {
                print_user_info();
                break;
            } else {
                std::cout << " [-] Login Failed: " << App.response.message << "\n\n";
            }
        } else if (choice == 2) {
            std::string user, pass, key;
            std::cout << " Enter Desired Username: ";
            std::cin >> user;
            std::cout << " Enter Password: ";
            std::cin >> pass;
            std::cout << " Enter License Key: ";
            std::cin >> key;

            std::cout << " [*] Registering account...\n";
            App.regstr(user, pass, key);

            if (App.response.success) {
                print_user_info();
                break;
            } else {
                std::cout << " [-] Registration Failed: " << App.response.message << "\n\n";
            }
        } else if (choice == 3) {
            std::string key;
            std::cout << " Enter License Key: ";
            std::cin >> key;

            std::cout << " [*] Authenticating License...\n";
            App.license(key);

            if (App.response.success) {
                print_user_info();
                break;
            } else {
                std::cout << " [-] License Check Failed: " << App.response.message << "\n\n";
            }
        } else if (choice == 4) {
            return 0;
        } else {
            std::cout << " Invalid option. Try again.\n\n";
        }
    }

    std::cout << "\n Program execution continuing... (Press any key to exit)\n";
    system("pause");
    return 0;
}
