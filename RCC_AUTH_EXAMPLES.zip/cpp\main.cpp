#include "RCCAuth.hpp"
#include <iostream>

using namespace RCCAuthSDK;

// =========================================================================
// RCC AUTH Client Credentials (RCC AUTH Architecture)
// =========================================================================
std::string name = skCrypt("RCCLoader").decrypt();       // App name
std::string ownerid = skCrypt("RCC_Dev1").decrypt();     // Account ID
std::string secret = skCrypt("RCCSec_9f83a12b4e76c5d9").decrypt(); // Application secret
std::string version = skCrypt("1.0.0").decrypt();       // Application version
std::string url = skCrypt("http://127.0.0.1:3000/api/v1/").decrypt(); // Server URL
std::string path = skCrypt("").decrypt();               // (OPTIONAL)

// Initialize Client API
RCCAuthSDK::api RCCAuthApp(name, ownerid, secret, version, url, path);

int main() {
    SetConsoleTitleA("RCC AUTH C++ Client Example");
    system("color 0b");

    std::cout << R"(
   ___    ___   ___      ___  __  __ _____ _  _ 
  | _ \  / __| / __|    /   \|  ||  |_   _| || |
  |   / | (__ | (__    / _ \ |  ||  | | | | __ |
  |_|_\  \___| \___|  /_/ \_\ \______/ |_| |_||_|
        C++ Native Win32 Client SDK (RCC AUTH Standard)
====================================================
)" << std::endl;

    std::cout << "[*] Initializing connection to: " << url << std::endl;
    std::cout << "[*] Machine HWID: " << RCCAuthSDK::api::get_hwid() << std::endl;

    RCCAuthApp.init();

    if (!RCCAuthApp.response.success) {
        std::cout << "[!] Init failed: " << RCCAuthApp.response.message << std::endl;
        system("pause");
        return 1;
    }

    std::cout << "[+] " << RCCAuthApp.response.message << std::endl;

    while (true) {
        std::cout << "\nChoose Option:\n [1] Login (User & Pass)\n [2] Register (User, Pass & Key)\n [3] License Only Auth\n [4] Exit\nChoice > ";
        int choice = 0;
        std::cin >> choice;

        if (choice == 1) {
            std::string user, pass;
            std::cout << "Username: "; std::cin >> user;
            std::cout << "Password: "; std::cin >> pass;

            std::cout << "[*] Authenticating..." << std::endl;
            RCCAuthApp.login(user, pass);

            if (RCCAuthApp.response.success) {
                std::cout << "\n[+] Login Successful!\n";
                std::cout << "User: " << RCCAuthApp.data.username << " | HWID: " << RCCAuthApp.data.hwid << "\n";
                std::cout << "Subscription: " << RCCAuthApp.data.subscription << "\n";
            } else {
                std::cout << "[!] Login failed: " << RCCAuthApp.response.message << std::endl;
            }
        } else if (choice == 2) {
            std::string user, pass, key;
            std::cout << "Username: "; std::cin >> user;
            std::cout << "Password: "; std::cin >> pass;
            std::cout << "License Key: "; std::cin >> key;

            std::cout << "[*] Registering..." << std::endl;
            RCCAuthApp.regstr(user, pass, key);

            if (RCCAuthApp.response.success) {
                std::cout << "\n[+] Registered Successfully!\n";
            } else {
                std::cout << "[!] Register failed: " << RCCAuthApp.response.message << std::endl;
            }
        } else if (choice == 3) {
            std::string key;
            std::cout << "License Key: "; std::cin >> key;

            std::cout << "[*] Authenticating key..." << std::endl;
            RCCAuthApp.license(key);

            if (RCCAuthApp.response.success) {
                std::cout << "\n[+] License Valid! Welcome.\n";
                std::cout << "Subscription: " << RCCAuthApp.data.subscription << "\n";
            } else {
                std::cout << "[!] License failed: " << RCCAuthApp.response.message << std::endl;
            }
        } else if (choice == 4) {
            break;
        }
    }

    return 0;
}
