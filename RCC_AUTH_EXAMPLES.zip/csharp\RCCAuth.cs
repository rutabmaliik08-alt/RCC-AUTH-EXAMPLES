using System;
using System.IO;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading.Tasks;

namespace RCCAuthSDK
{
    public class ResponseData
    {
        public bool success { get; set; } = false;
        public string message { get; set; } = string.Empty;
    }

    public class UserData
    {
        public string username { get; set; } = string.Empty;
        public string ip { get; set; } = string.Empty;
        public string hwid { get; set; } = string.Empty;
        public string createdate { get; set; } = string.Empty;
        public string lastlogin { get; set; } = string.Empty;
        public string subscription { get; set; } = "Lifetime Active";
        public string expiry { get; set; } = "Lifetime";
        public int rank { get; set; } = 1;
        public long remainingSeconds { get; set; } = -1;
    }

    public class api
    {
        public string Name { get; set; }
        public string OwnerId { get; set; }
        public string Secret { get; set; }
        public string Version { get; set; }
        public string Url { get; set; }
        public string Path { get; set; }

        public ResponseData response { get; set; } = new ResponseData();
        public UserData data { get; set; } = new UserData();
        public string SessionId { get; private set; } = string.Empty;
        public bool IsInitialized { get; private set; } = false;

        private readonly HttpClient _httpClient;

        public api(string name, string ownerid, string secret, string version, string url = "http://127.0.0.1:3000/api/v1/", string path = "")
        {
            Name = name;
            OwnerId = ownerid;
            Secret = secret;
            Version = version;
            Url = url.TrimEnd('/') + "/";
            Path = path;

            // Use SocketsHttpHandler or HttpClientHandler with SSL certificate bypass for maximum compatibility
            var handler = new HttpClientHandler
            {
                ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => true
            };

            _httpClient = new HttpClient(handler)
            {
                Timeout = TimeSpan.FromSeconds(15)
            };
        }

        public bool checkblack() => Task.Run(async () => await checkblackAsync()).GetAwaiter().GetResult();
        public async Task<bool> checkblackAsync()
        {
            var payload = new { secret = Secret, hwid = GetHWID() };
            var json = await SendPostAsync("checkblack", payload);
            bool blk = json?["blacklisted"]?.GetValue<bool>() ?? false;
            if (blk) response.message = json?["reason"]?.GetValue<string>() ?? "Blacklisted.";
            return blk;
        }

        public bool heartbeat() => Task.Run(async () => await heartbeatAsync()).GetAwaiter().GetResult();
        public async Task<bool> heartbeatAsync()
        {
            if (string.IsNullOrEmpty(SessionId)) return false;
            var payload = new { secret = Secret, session_id = SessionId };
            var json = await SendPostAsync("heartbeat", payload);
            bool valid = json?["valid"]?.GetValue<bool>() ?? false;
            if (!valid)
            {
                response.success = false;
                response.message = json?["message"]?.GetValue<string>() ?? "Session invalidated.";
            }
            return valid;
        }

        public bool hwidReset(string username, string password, string reason = "HWID Reset") => Task.Run(async () => await hwidResetAsync(username, password, reason)).GetAwaiter().GetResult();
        public async Task<bool> hwidResetAsync(string username, string password, string reason = "HWID Reset")
        {
            var payload = new { secret = Secret, username, password, reason };
            var json = await SendPostAsync("hwid_reset", payload);
            response.success = json?["success"]?.GetValue<bool>() ?? false;
            response.message = json?["message"]?.GetValue<string>() ?? "Failed";
            return response.success;
        }

        public byte[] download(string fileName) => Task.Run(async () => await downloadAsync(fileName)).GetAwaiter().GetResult();
        public async Task<byte[]> downloadAsync(string fileName)
        {
            if (!IsInitialized) await initAsync();
            var payload = new { secret = Secret, file_name = fileName, format = "base64" };
            var json = await SendPostAsync("file", payload);
            if (json?["success"]?.GetValue<bool>() == true && json["base64_data"] != null)
            {
                return Convert.FromBase64String(json["base64_data"]!.GetValue<string>());
            }
            return Array.Empty<byte>();
        }

        #region Hardware ID Generator
        public static string GetHWID()
        {
            try
            {
                string rawHwid = $"{Environment.MachineName}-{Environment.UserName}-{Environment.ProcessorCount}-{GetWindowsVolumeSerial()}";
                using var sha256 = SHA256.Create();
                byte[] hash = sha256.ComputeHash(Encoding.UTF8.GetBytes(rawHwid));
                return Convert.ToHexString(hash).ToLower();
            }
            catch
            {
                return "HWID-FALLBACK-" + Environment.MachineName.GetHashCode();
            }
        }

        private static string GetWindowsVolumeSerial()
        {
            try
            {
                string systemDrive = System.IO.Path.GetPathRoot(Environment.SystemDirectory) ?? "C:\\";
                var driveInfo = new DriveInfo(systemDrive);
                return driveInfo.VolumeLabel + driveInfo.TotalSize.ToString();
            }
            catch
            {
                return "VOL-DEFAULT";
            }
        }
        #endregion

        private async Task<JsonObject?> SendPostAsync(string endpoint, object payloadObj)
        {
            try
            {
                string jsonString = JsonSerializer.Serialize(payloadObj);
                var content = new StringContent(jsonString, Encoding.UTF8, "application/json");

                var request = new HttpRequestMessage(HttpMethod.Post, Url + endpoint)
                {
                    Content = content
                };
                request.Headers.Add("x-app-secret", Secret);

                var httpResponse = await _httpClient.SendAsync(request);
                string responseBody = await httpResponse.Content.ReadAsStringAsync();

                return JsonNode.Parse(responseBody)?.AsObject();
            }
            catch (Exception ex)
            {
                var errObj = new JsonObject
                {
                    ["success"] = false,
                    ["message"] = "Network error: " + ex.Message
                };
                return errObj;
            }
        }

        public void init() => Task.Run(async () => await initAsync()).GetAwaiter().GetResult();
        public async Task initAsync()
        {
            var payload = new
            {
                name = Name,
                ownerid = OwnerId,
                secret = Secret,
                version = Version
            };

            var json = await SendPostAsync("init", payload);
            response.success = json?["success"]?.GetValue<bool>() ?? false;
            response.message = json?["message"]?.GetValue<string>() ?? "No response";

            if (response.success)
            {
                SessionId = json?["session_id"]?.GetValue<string>() ?? string.Empty;
                IsInitialized = true;
            }
        }

        public void login(string username, string password) => Task.Run(async () => await loginAsync(username, password)).GetAwaiter().GetResult();
        public async Task loginAsync(string username, string password)
        {
            if (!IsInitialized) await initAsync();

            var payload = new
            {
                secret = Secret,
                ownerid = OwnerId,
                username,
                password,
                hwid = GetHWID()
            };

            var json = await SendPostAsync("login", payload);
            HandleAuthJson(json);
        }

        public void regstr(string username, string password, string licenseKey) => Task.Run(async () => await regstrAsync(username, password, licenseKey)).GetAwaiter().GetResult();
        public async Task regstrAsync(string username, string password, string licenseKey)
        {
            if (!IsInitialized) await initAsync();

            var payload = new
            {
                secret = Secret,
                ownerid = OwnerId,
                username,
                password,
                license_key = licenseKey,
                hwid = GetHWID()
            };

            var json = await SendPostAsync("register", payload);
            HandleAuthJson(json);
        }

        public void license(string licenseKey) => Task.Run(async () => await licenseAsync(licenseKey)).GetAwaiter().GetResult();
        public async Task licenseAsync(string licenseKey)
        {
            if (!IsInitialized) await initAsync();

            var payload = new
            {
                secret = Secret,
                ownerid = OwnerId,
                license_key = licenseKey,
                hwid = GetHWID()
            };

            var json = await SendPostAsync("license", payload);
            HandleAuthJson(json);
        }

        public void upgrade(string username, string licenseKey) => Task.Run(async () => await upgradeAsync(username, licenseKey)).GetAwaiter().GetResult();
        public async Task upgradeAsync(string username, string licenseKey)
        {
            if (!IsInitialized) await initAsync();

            var payload = new
            {
                secret = Secret,
                username,
                license_key = licenseKey
            };

            var json = await SendPostAsync("upgrade", payload);
            response.success = json?["success"]?.GetValue<bool>() ?? false;
            response.message = json?["message"]?.GetValue<string>() ?? "No response";
        }

        public string var(string varName) => Task.Run(async () => await varAsync(varName)).GetAwaiter().GetResult();
        public async Task<string> varAsync(string varName)
        {
            if (!IsInitialized) await initAsync();

            var payload = new
            {
                secret = Secret,
                var_name = varName
            };

            var json = await SendPostAsync("var", payload);
            if (json?["success"]?.GetValue<bool>() == true)
            {
                return json["var_value"]?.GetValue<string>() ?? string.Empty;
            }
            return string.Empty;
        }

        public void log(string message) => Task.Run(async () => await logAsync(message)).GetAwaiter().GetResult();
        public async Task logAsync(string message)
        {
            var payload = new
            {
                secret = Secret,
                message,
                hwid = GetHWID()
            };
            await SendPostAsync("log", payload);
        }

        private void HandleAuthJson(JsonObject? json)
        {
            response.success = json?["success"]?.GetValue<bool>() ?? false;
            response.message = json?["message"]?.GetValue<string>() ?? string.Empty;

            if (response.success)
            {
                string? sid = json?["session_id"]?.GetValue<string>();
                if (!string.IsNullOrEmpty(sid)) SessionId = sid;
                if (json?["user"] != null)
                {
                    var u = json["user"]!.AsObject();
                    data.username = u["username"]?.GetValue<string>() ?? string.Empty;
                    data.hwid = u["hwid"]?.GetValue<string>() ?? string.Empty;
                    data.rank = u["rank"]?.GetValue<int>() ?? 1;
                    data.expiry = u["expires_at"]?.GetValue<string>() ?? "Lifetime";
                    data.createdate = u["created_at"]?.GetValue<string>() ?? string.Empty;
                    data.lastlogin = u["last_login"]?.GetValue<string>() ?? string.Empty;
                    data.subscription = string.IsNullOrEmpty(data.expiry) || data.expiry == "Lifetime" ? "Lifetime Active" : $"Active ({data.expiry})";
                }
                else
                {
                    data.username = json?["username"]?.GetValue<string>() ?? string.Empty;
                    data.hwid = json?["hwid"]?.GetValue<string>() ?? string.Empty;
                    data.expiry = json?["expires_at"]?.GetValue<string>() ?? "Lifetime";
                    data.subscription = string.IsNullOrEmpty(data.expiry) || data.expiry == "Lifetime" ? "Lifetime Active" : $"Active ({data.expiry})";
                }
            }
        }
    }
}
