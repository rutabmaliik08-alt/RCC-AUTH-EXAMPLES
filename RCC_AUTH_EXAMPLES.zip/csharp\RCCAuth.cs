﻿using System;
using System.IO;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading.Tasks;

namespace RCCAuthSDK
{
    public class ResponseData
    {
        public bool success { get; set; } = false;
        public string message { get; set; } = string.Empty;
    }

    public class UserData
    {
        public string username { get; set; } = string.Empty;
        public string ip { get; set; } = string.Empty;
        public string hwid { get; set; } = string.Empty;
        public string createdate { get; set; } = string.Empty;
        public string lastlogin { get; set; } = string.Empty;
        public string subscription { get; set; } = "Lifetime Active";
        public string expiry { get; set; } = "Lifetime";
        public int rank { get; set; } = 1;
        public long remainingSeconds { get; set; } = -1;
    }

    public class api
    {
        public string Name { get; set; }
        public string OwnerId { get; set; }
        public string Secret { get; set; }
        public string Version { get; set; }
        public string Url { get; set; }
        public string Path { get; set; }

        public ResponseData response { get; set; } = new ResponseData();
        public UserData data { get; set; } = new UserData();
        public string SessionId { get; private set; } = string.Empty;
        public bool IsInitialized { get; private set; } = false;

        private readonly HttpClient _httpClient;

        public api(string name, string ownerid, string secret, string version, string url = "http://127.0.0.1:3000/api/v1/", string path = "")
        {
            Name = name;
            OwnerId = ownerid;
            Secret = secret;
            Version = version;
            Url = url.TrimEnd('/') + "/";
            Path = path;

            _httpClient = new HttpClient
            {
                Timeout = TimeSpan.FromSeconds(15)
            };
        }

        #region Hardware ID Generator
        public static string GetHWID()
        {
            try
            {
                string rawHwid = $"{Environment.MachineName}-{Environment.UserName}-{Environment.ProcessorCount}-{GetWindowsVolumeSerial()}";
                using var sha256 = SHA256.Create();
                byte[] hash = sha256.ComputeHash(Encoding.UTF8.GetBytes(rawHwid));
                return Convert.ToHexString(hash);
            }
            catch
            {
                return "HWID-FALLBACK-" + Environment.MachineName.GetHashCode();
            }
        }

        private static string GetWindowsVolumeSerial()
        {
            try
            {
                string systemDrive = System.IO.Path.GetPathRoot(Environment.SystemDirectory) ?? "C:\\";
                var driveInfo = new DriveInfo(systemDrive);
                return driveInfo.VolumeLabel + driveInfo.TotalSize.ToString();
            }
            catch
            {
                return "VOL-DEFAULT";
            }
        }
        #endregion

        private async Task<JsonObject?> SendPostAsync(string endpoint, object payloadObj)
        {
            try
            {
                string jsonString = JsonSerializer.Serialize(payloadObj);
                var content = new StringContent(jsonString, Encoding.UTF8, "application/json");

                var request = new HttpRequestMessage(HttpMethod.Post, Url + endpoint)
                {
                    Content = content
                };
                request.Headers.Add("x-app-secret", Secret);

                var httpResponse = await _httpClient.SendAsync(request);
                string responseBody = await httpResponse.Content.ReadAsStringAsync();

                return JsonNode.Parse(responseBody)?.AsObject();
            }
            catch (Exception ex)
            {
                var errObj = new JsonObject
                {
                    ["success"] = false,
                    ["message"] = "Network error: " + ex.Message
                };
                return errObj;
            }
        }

        public void init() => Task.Run(async () => await initAsync()).GetAwaiter().GetResult();
        public async Task initAsync()
        {
            var payload = new
            {
                name = Name,
                ownerid = OwnerId,
                secret = Secret,
                version = Version
            };

            var json = await SendPostAsync("init", payload);
            response.success = json?["success"]?.GetValue<bool>() ?? false;
            response.message = json?["message"]?.GetValue<string>() ?? "No response";

            if (response.success)
            {
                SessionId = json?["session_id"]?.GetValue<string>() ?? string.Empty;
                IsInitialized = true;
            }
        }

        public void login(string username, string password) => Task.Run(async () => await loginAsync(username, password)).GetAwaiter().GetResult();
        public async Task loginAsync(string username, string password)
        {
            if (!IsInitialized) await initAsync();

            var payload = new
            {
                secret = Secret,
                ownerid = OwnerId,
                username,
                password,
                hwid = GetHWID()
            };

            var json = await SendPostAsync("login", payload);
            HandleAuthJson(json);
        }

        public void regstr(string username, string password, string licenseKey) => Task.Run(async () => await regstrAsync(username, password, licenseKey)).GetAwaiter().GetResult();
        public async Task regstrAsync(string username, string password, string licenseKey)
        {
            if (!IsInitialized) await initAsync();

            var payload = new
            {
                secret = Secret,
                ownerid = OwnerId,
                username,
                password,
                license_key = licenseKey,
                hwid = GetHWID()
            };

            var json = await SendPostAsync("register", payload);
            HandleAuthJson(json);
        }

        public void license(string licenseKey) => Task.Run(async () => await licenseAsync(licenseKey)).GetAwaiter().GetResult();
        public async Task licenseAsync(string licenseKey)
        {
            if (!IsInitialized) await initAsync();

            var payload = new
            {
                secret = Secret,
                ownerid = OwnerId,
                license_key = licenseKey,
                hwid = GetHWID()
            };

            var json = await SendPostAsync("license", payload);
            HandleAuthJson(json);
        }

        public string var(string varName) => Task.Run(async () => await varAsync(varName)).GetAwaiter().GetResult();
        public async Task<string> varAsync(string varName)
        {
            if (!IsInitialized) await initAsync();

            var payload = new
            {
                secret = Secret,
                var_name = varName
            };

            var json = await SendPostAsync("var", payload);
            if (json?["success"]?.GetValue<bool>() == true)
            {
                return json["var_value"]?.GetValue<string>() ?? string.Empty;
            }
            return string.Empty;
        }

        public byte[] download(string fileId) => Task.Run(async () => await downloadAsync(fileId)).GetAwaiter().GetResult();
        public async Task<byte[]> downloadAsync(string fileId)
        {
            if (!IsInitialized) await initAsync();

            var payload = new
            {
                secret = Secret,
                file_id = fileId
            };

            var json = await SendPostAsync("download", payload);
            if (json?["success"]?.GetValue<bool>() == true && json["file_data"] != null)
            {
                return Convert.FromBase64String(json["file_data"]!.GetValue<string>());
            }
            return Array.Empty<byte>();
        }

        public void log(string message) => Task.Run(async () => await logAsync(message)).GetAwaiter().GetResult();
        public async Task logAsync(string message)
        {
            var payload = new
            {
                secret = Secret,
                message
            };
            await SendPostAsync("log", payload);
        }

        private void HandleAuthJson(JsonObject? json)
        {
            response.success = json?["success"]?.GetValue<bool>() ?? false;
            response.message = json?["message"]?.GetValue<string>() ?? string.Empty;

            if (response.success && json?["user"] != null)
            {
                var u = json["user"]!.AsObject();
                data.username = u["username"]?.GetValue<string>() ?? string.Empty;
                data.hwid = u["hwid"]?.GetValue<string>() ?? string.Empty;
                data.rank = u["rank"]?.GetValue<int>() ?? 1;
                data.expiry = u["expires_at"]?.GetValue<string>() ?? "Lifetime";
                data.createdate = u["created_at"]?.GetValue<string>() ?? string.Empty;
                data.lastlogin = u["last_login"]?.GetValue<string>() ?? string.Empty;
                data.subscription = string.IsNullOrEmpty(data.expiry) || data.expiry == "Lifetime" ? "Lifetime Active" : $"Active ({data.expiry})";
            }
        }
    }
}
