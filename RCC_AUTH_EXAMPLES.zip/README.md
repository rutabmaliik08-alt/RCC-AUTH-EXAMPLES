# RCC AUTH — Latest Official Integration Examples

Complete, fully working, and modernized client SDK examples for **C++**, **C# (.NET)**, and **Python**, tested and verified with the latest RCC AUTH backend architecture.

---

## 📁 Folder Structure

```
latest examples/
├── cpp/
│   ├── RCCAuth.hpp          # Header-only WinINet C++ SDK with embedded skCrypt
│   ├── main.cpp             # Interactive console demonstration
│   ├── build.bat            # 1-Click MSVC build script
│   └── CMakeLists.txt       # CMake project file for Visual Studio / CLion
├── csharp/
│   ├── RCCAuth.cs           # C# SDK with sync & async HttpClient methods
│   ├── Program.cs           # Interactive console demonstration
│   └── RCCAuthExample.csproj # .NET 8.0 project file
├── python/
│   ├── rccauth.py           # Python SDK with requests & Windows HWID lock
│   ├── main.py              # Interactive console demonstration
│   └── requirements.txt     # Python dependencies
└── README.md                # Documentation guide
```

---

## ⚙️ Configuration Setup

In each example (`main.cpp`, `Program.cs`, or `main.py`), set your application credentials obtained from your RCC AUTH Dashboard:

| Parameter | Description | Example |
| :--- | :--- | :--- |
| `name` | Your Application Name | `"RCC_INTERNAL+EXTERNAL"` |
| `ownerid` | Your Developer Owner ID | `"RCC_46"` |
| `secret` | Application Master Secret | `"RCCSec_0ef6101773f71c35c57ae205"` |
| `version` | Product Version | `"1.0.0"` |
| `url` | RCC Auth API Endpoint | `"https://white-owl-688321.hostingersite.com/api/v1/"` |

---

## 🚀 Running the Examples

### 1. C++ (Windows Win32 / DirectX / Native)
- **Header Only**: Simply `#include "RCCAuth.hpp"` in your project.
- **Embedded skCrypt**: All strings can be encrypted at compile-time with `skCrypt("string")`.
- **Compile via MSVC CLI**:
  ```cmd
  cd cpp
  build.bat
  ```
- **Or compile manually**:
  ```cmd
  cl.exe /EHsc /std:c++17 /O2 main.cpp /link wininet.lib crypt32.lib advapi32.lib /out:RCCAuthDemo.exe
  ```

### 2. C# (.NET Core / .NET 6/7/8)
- Requires .NET 6.0 or higher.
- **Run**:
  ```cmd
  cd csharp
  dotnet run
  ```

### 3. Python 3
- Requires Python 3.8+.
- **Install dependencies and run**:
  ```cmd
  cd python
  pip install -r requirements.txt
  python main.py
  ```

---

## 🔒 Features Included
- **Cryptographic HWID Lock**: Machine-bound SHA256 hardware identifier automatically enforced.
- **skCrypt Protection**: C++ strings are obfuscated at compile-time to prevent memory string dumping.
- **Flexible SSL Handling**: Automatic handling of HTTPS certificates for Cloudflare, Hostinger, and custom domains.
- **License-Only or User/Pass**: Supports both keyless license redemption and user accounts.
- **Cloud Variables**: Read remote protected variables/offsets securely without exposing them in client binaries.
- **Audit Logging**: Report security handshakes and cheat/client events directly to the dashboard.
