﻿# RCC AUTH - Official Client SDKs & Integration Examples

Welcome to the official repository of integration examples and client SDKs for **RCC AUTH**.

This repository contains fully tested, production-grade example implementations for integrating RCC AUTH licensing, authentication, hardware locking (HWID), and remote cloud variables into your software and Discord communities.

---

## 📁 Repository Structure

| Folder | Platform / Language | Features Included |
| :--- | :--- | :--- |
| [cpp/](./cpp) | **C++ Win32 (Console)** | Native WinINet HTTP, skCrypt compile-time string encryption, HWID check, License auth, Cloud variables. |
| [cpp_gui_app/](./cpp_gui_app) | **C++ Win32 (GUI App)** | Clean Windows desktop dialog GUI, dark theme styling, key activation, status feedback. |
| [csharp/](./csharp) | **C# .NET (Console / GUI)** | Supports .NET Framework & .NET 6/7/8/9, AES payload encryption, auto-HWID hashing, session validation. |
| [python/](./python) | **Python 3.x** | Cross-platform client SDK with ccauth.py, session heartbeat, variable streaming, file downloads. |
| [discord_bot_js/](./discord_bot_js) | **Discord Bot (Node.js)** | Discord.js v14 slash commands: /genkey, /checkkey, /resethwid, /userinfo, /banuser. |
| [discord_bot_python/](./discord_bot_python) | **Discord Bot (Python)** | Discord.py slash commands: /genkey, /checkkey, /resethwid, /userinfo, /banuser, /extend. |

---

## 🚀 Quick Setup Instructions

### 1. Prerequisites
Obtain your credentials from your **RCC AUTH Dashboard**:
1. **Server URL**: Your public domain or IP (e.g., https://auth.yourdomain.com/api/v1/ or http://localhost:3000/api/v1/).
2. **App Name**: The exact name configured in RCC AUTH (e.g., RCCLoader).
3. **App Secret**: The 32-character secret key generated for your application.
4. **App Version**: Version number (e.g., 1.0.0).
5. **Seller Key** *(For Discord Bots only)*: Generated from **Dashboard > API & Discord Bot Keys**.

---

### 2. C++ Console Quickstart (examples/cpp)
- Open examples/cpp/main.cpp
- Fill in your 
ame, ownerid, secret, ersion, and url.
- Compile using Visual Studio (MSVC) or run uild.bat.

### 3. C++ GUI Application (examples/cpp_gui_app)
- Double click uild.bat using **x64 Native Tools Command Prompt for VS**.
- Run RCCAuthGuiApp.exe.

### 4. C# .NET Quickstart (examples/csharp)
`ash
cd csharp
dotnet build
dotnet run
`

### 5. Python 3 Client (examples/python)
`ash
cd python
pip install -r requirements.txt
python main.py
`

### 6. Discord Bots
#### Node.js (examples/discord_bot_js)
`ash
cd discord_bot_js
npm install
# Set DISCORD_BOT_TOKEN and RCC_SELLER_KEY in bot.js or .env
node bot.js
`

#### Python (examples/discord_bot_python)
`ash
cd discord_bot_python
pip install -r requirements.txt
# Set DISCORD_BOT_TOKEN and RCC_SELLER_KEY in bot.py
python bot.py
`

---

## 🔒 Security Notice
- Always use skCrypt or binary obfuscation for native C++ and C# deployments to protect your App Secret.
- Keep your Seller API keys private and never distribute them to end users.
